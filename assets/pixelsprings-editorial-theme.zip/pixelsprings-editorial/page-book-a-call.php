<?php
/**
 * Template Name: Book a Call Page
 * The template for displaying the Book a Call page (/book-a-call)
 *
 * @package Pixelsprings
 */
get_header(); ?>

<main id="main" class="inner-main">
  <!-- PAGE HERO -->
  <section class="inner-hero inner-hero-left">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('Let\'s talk', 'pixelsprings'); ?></div>
      <h1><?php _e('Let\'s talk about<br>what you\'re building.', 'pixelsprings'); ?></h1>
      <p><?php esc_html_e('Tell us a little about your team, the work you need help with, and where additional production capacity would make a difference.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- BOOKING PANEL -->
  <section class="section booking-section">
    <div class="wrap">
      <div class="booking-panel">
        <div class="eyebrow"><?php esc_html_e('Book a time', 'pixelsprings'); ?></div>
        <h2><?php esc_html_e('Scheduling integration goes here.', 'pixelsprings'); ?></h2>
        <p><?php esc_html_e('A booking link or scheduling embed will be added when one is available.', 'pixelsprings'); ?></p>
        <span class="booking-rule" aria-hidden="true"></span>
      </div>
    </div>
  </section>

  <!-- WRITE INSTEAD ALTERNATIVE -->
  <section class="section book-alternative">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('Prefer to write?', 'pixelsprings'); ?></div>
      <h2><?php esc_html_e('Not ready for a call?', 'pixelsprings'); ?></h2>
      <p><?php esc_html_e('Send us a message instead.', 'pixelsprings'); ?></p>
      <a class="button button-dark" href="<?php echo esc_url(home_url('/contact')); ?>"><?php _e('Send a Message <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></a>
    </div>
  </section>
</main>

<?php get_footer(); ?>
