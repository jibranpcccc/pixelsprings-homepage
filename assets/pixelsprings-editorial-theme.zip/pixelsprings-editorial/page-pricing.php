<?php
/**
 * Template Name: Pricing Page
 * The template for displaying the Pricing page (/pricing)
 *
 * @package Pixelsprings
 */
get_header(); ?>

<main id="main" class="inner-main">
  <!-- PAGE HERO -->
  <section class="inner-hero inner-hero-left">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('Pricing', 'pixelsprings'); ?></div>
      <h1><?php _e('Choose the production capacity<br>that fits your team.', 'pixelsprings'); ?></h1>
      <p><?php esc_html_e('One simple monthly subscription. Choose the level of production capacity that fits the way your team works.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- PRICING MATRIX -->
  <section id="pricing-plans" class="section pricing inner-pricing">
    <div class="wrap">
      <p class="pricing-scroll-hint"><?php _e('Swipe to compare all three plans <span aria-hidden="true">→</span>', 'pixelsprings'); ?></p>
      <div class="pricing-scroll" role="region" aria-label="<?php esc_attr_e('Pricing comparison; scroll horizontally to compare all plans', 'pixelsprings'); ?>" tabindex="0" data-testid="pricing-comparison">
        <div class="price-table">
          <div class="price-head">
            <div class="price-plan"><span class="eyebrow"><?php esc_html_e('Monthly subscription', 'pixelsprings'); ?></span></div>
            <div class="price-plan">
              <h3>PIXEL SPARK</h3>
              <div class="price">$799<small>/month</small></div>
              <p><?php esc_html_e('1 active request', 'pixelsprings'); ?><br><?php esc_html_e('Graphic Design Subscription', 'pixelsprings'); ?></p>
              <a class="button button-light" href="mailto:contact@pixelsprings.com?subject=Pixel%20Spark%20plan" data-testid="link-plan-1"><?php esc_html_e('Choose Spark', 'pixelsprings'); ?></a>
            </div>
            <div class="price-plan featured">
              <h3>PIXEL FLOW</h3>
              <div class="price">$1,499<small>/month</small></div>
              <p><?php esc_html_e('2 active requests', 'pixelsprings'); ?><br><?php esc_html_e('Design + UI/UX + Web', 'pixelsprings'); ?></p>
              <a class="button button-dark" href="mailto:contact@pixelsprings.com?subject=Pixel%20Flow%20plan" data-testid="link-plan-2"><?php esc_html_e('Choose Flow', 'pixelsprings'); ?></a>
            </div>
            <div class="price-plan">
              <h3>PIXEL FORGE</h3>
              <div class="price">$2,499<small>/month</small></div>
              <p><?php esc_html_e('3 active requests', 'pixelsprings'); ?><br><?php esc_html_e('Design + Web + Development', 'pixelsprings'); ?></p>
              <a class="button button-light" href="mailto:contact@pixelsprings.com?subject=Pixel%20Forge%20plan" data-testid="link-plan-3"><?php esc_html_e('Choose Forge', 'pixelsprings'); ?></a>
            </div>
          </div>

          <!-- DESIGN CATEGORY -->
          <div class="price-row category"><span>DESIGN</span><span></span><span></span><span></span></div>
          <?php
          $design_items = array(
            'Graphic design' => array(true, true, true),
            'Logo design' => array(true, true, true),
            'Branding' => array(true, true, true),
            'Packaging' => array(true, true, true),
            'Print materials' => array(true, true, true),
            'Social media creatives' => array(true, true, true),
            'Advertising creatives' => array(true, true, true),
            'Marketing collateral' => array(true, true, true),
            'Presentation design' => array(true, true, true),
          );
          $row = 1;
          foreach ($design_items as $item => $avail): ?>
          <div class="price-row" data-testid="row-feature-design-<?php echo esc_attr($row++); ?>">
            <span><?php echo esc_html($item); ?></span>
            <?php foreach ($avail as $inc): ?>
            <span role="img" class="<?php echo $inc ? 'yes' : 'not-yet'; ?>" aria-label="<?php echo $inc ? 'Included' : 'Not included'; ?>"><?php echo $inc ? '✓' : '—'; ?></span>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>

          <!-- DIGITAL CATEGORY -->
          <div class="price-row category"><span>DIGITAL</span><span></span><span></span><span></span></div>
          <?php
          $digital_items = array(
            'UI/UX' => array(false, true, true),
            'Figma' => array(false, true, true),
            'Website design' => array(false, true, true),
            'Landing pages' => array(false, true, true),
            'WordPress' => array(false, true, true),
            'Webflow' => array(false, true, true),
            'Website redesigns' => array(false, true, true),
            'Website updates' => array(false, true, true),
            'Responsive implementation' => array(false, true, true),
          );
          $row = 1;
          foreach ($digital_items as $item => $avail): ?>
          <div class="price-row" data-testid="row-feature-digital-<?php echo esc_attr($row++); ?>">
            <span><?php echo esc_html($item); ?></span>
            <?php foreach ($avail as $inc): ?>
            <span role="img" class="<?php echo $inc ? 'yes' : 'not-yet'; ?>" aria-label="<?php echo $inc ? 'Included' : 'Not included'; ?>"><?php echo $inc ? '✓' : '—'; ?></span>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>

          <!-- DEVELOPMENT CATEGORY -->
          <div class="price-row category"><span>DEVELOPMENT</span><span></span><span></span><span></span></div>
          <?php
          $dev_items = array(
            'Custom coding' => array(false, false, true),
            'Advanced WordPress' => array(false, false, true),
            'WooCommerce' => array(false, false, true),
            'E-commerce' => array(false, false, true),
            'Custom functionality' => array(false, false, true),
            'API / integrations' => array(false, false, true),
            'Third-party integrations' => array(false, false, true),
            'Front-end / back-end development' => array(false, false, true),
          );
          $row = 1;
          foreach ($dev_items as $item => $avail): ?>
          <div class="price-row" data-testid="row-feature-development-<?php echo esc_attr($row++); ?>">
            <span><?php echo esc_html($item); ?></span>
            <?php foreach ($avail as $inc): ?>
            <span role="img" class="<?php echo $inc ? 'yes' : 'not-yet'; ?>" aria-label="<?php echo $inc ? 'Included' : 'Not included'; ?>"><?php echo $inc ? '✓' : '—'; ?></span>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- THE WORKING MODEL -->
  <section class="section pricing-details" aria-labelledby="subscription-works-title">
    <div class="wrap">
      <div class="editorial-heading">
        <div class="eyebrow"><?php esc_html_e('The working model', 'pixelsprings'); ?></div>
        <h2 id="subscription-works-title"><?php esc_html_e('How your subscription works', 'pixelsprings'); ?></h2>
        <p><?php esc_html_e('Keep the queue full of useful work. Your plan sets how much can be in production at once.', 'pixelsprings'); ?></p>
      </div>
      <div class="pricing-detail-grid">
        <article>
          <div class="eyebrow"><?php esc_html_e('01 / Queue & capacity', 'pixelsprings'); ?></div>
          <h3><?php esc_html_e('Unlimited requests, clear capacity.', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Add unlimited requests to your queue and set priorities. Active capacity is plan-based: Spark has 1 active request, Flow has 2, and Forge has 3. Work moves into production within that capacity.', 'pixelsprings'); ?></p>
          <ul class="detail-list">
            <li><?php esc_html_e('Pixel Spark — 1 active request', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Pixel Flow — 2 active requests', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Pixel Forge — 3 active requests', 'pixelsprings'); ?></li>
          </ul>
        </article>
        <article>
          <div class="eyebrow"><?php esc_html_e('02 / What counts as a request', 'pixelsprings'); ?></div>
          <h3><?php esc_html_e('A defined piece of work.', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('A request is a deliverable or a clearly scoped task. For example: a logo, social creative, presentation, landing page, website section, UI screen, website update, or development task.', 'pixelsprings'); ?></p>
        </article>
        <article>
          <div class="eyebrow"><?php esc_html_e('03 / Review & scope', 'pixelsprings'); ?></div>
          <h3><?php esc_html_e('Refine the original brief.', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('A request stays active while it is being produced, reviewed, or revised. Request revisions within the original scope; if a change becomes a materially different deliverable, it becomes a new request.', 'pixelsprings'); ?></p>
        </article>
        <article>
          <div class="eyebrow"><?php esc_html_e('04 / Larger projects', 'pixelsprings'); ?></div>
          <h3><?php esc_html_e('Big work, in milestones.', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Large websites, e-commerce projects, and complex development are handled in milestones within your active capacity. Milestones keep the work defined while it moves through the queue.', 'pixelsprings'); ?></p>
        </article>
      </div>
      <div class="workload-note">
        <h3><?php esc_html_e('When your workload changes', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('Capacity remains based on your plan, and requests can stay queued. Contact Pixelsprings to discuss which current plan fits your team\'s workload.', 'pixelsprings'); ?></p>
      </div>
    </div>
  </section>

  <!-- EXPECTATIONS -->
  <section class="section pricing-expectations" aria-labelledby="expect-title">
    <div class="wrap expectation-layout">
      <div class="expectation-heading">
        <div class="eyebrow"><?php esc_html_e('A practical rhythm', 'pixelsprings'); ?></div>
        <h2 id="expect-title"><?php esc_html_e('What to expect', 'pixelsprings'); ?></h2>
      </div>
      <div class="expectation-content">
        <p class="expectation-lede"><?php esc_html_e('A visible queue and a steady review cycle make it easier to plan the next piece of work.', 'pixelsprings'); ?></p>
        <ul class="expectation-list">
          <li><strong><?php esc_html_e('A clear production queue', 'pixelsprings'); ?></strong><span><?php esc_html_e('Requests stay organized so priorities are easy to see.', 'pixelsprings'); ?></span></li>
          <li><strong><?php esc_html_e('Capacity based on your plan', 'pixelsprings'); ?></strong><span><?php esc_html_e('Spark, Flow, and Forge each have a defined number of active requests.', 'pixelsprings'); ?></span></li>
          <li><strong><?php esc_html_e('Progress and review', 'pixelsprings'); ?></strong><span><?php esc_html_e('Work is shared for your review, with revisions within the original scope.', 'pixelsprings'); ?></span></li>
          <li><strong><?php esc_html_e('Flexible ongoing production', 'pixelsprings'); ?></strong><span><?php esc_html_e('Keep work moving as needs come up, with requests queued when capacity is full.', 'pixelsprings'); ?></span></li>
          <li><strong><?php esc_html_e('No long-term contract', 'pixelsprings'); ?></strong><span><?php esc_html_e('The subscription is designed for ongoing production without a long-term commitment.', 'pixelsprings'); ?></span></li>
        </ul>
      </div>
    </div>
  </section>

  <!-- CLOSING CTA -->
  <section class="final-cta inner-final-cta">
    <div class="eyebrow"><?php esc_html_e('Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></div>
    <h2><?php _e('Find the right rhythm<br><span class="cta-highlight">for your team.</span>', 'pixelsprings'); ?></h2>
    <div class="final-actions">
      <a class="button button-dark" href="<?php echo esc_url(home_url('/book-a-call')); ?>"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <a class="button button-light" href="#pricing-plans"><?php esc_html_e('Choose a Plan', 'pixelsprings'); ?></a>
    </div>
  </section>
</main>

<?php get_footer(); ?>
