<?php
/**
 * Template Name: Contact Page
 * The template for displaying the Contact page (/contact)
 *
 * @package Pixelsprings
 */
get_header(); ?>

<main id="main" class="inner-main">
  <!-- PAGE HERO -->
  <section class="inner-hero inner-hero-left">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('Contact', 'pixelsprings'); ?></div>
      <h1><?php esc_html_e('Have a question?', 'pixelsprings'); ?></h1>
      <p><?php esc_html_e('We’d love to hear from you. Tell us a little about the work you have in mind.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- INNER CONTACT SECTION -->
  <section class="section contact inner-contact" id="contact" aria-labelledby="contact-title">
    <div class="wrap contact-grid">
      <div class="contact-title">
        <div class="eyebrow"><?php esc_html_e('Start a conversation', 'pixelsprings'); ?></div>
        <h2><?php esc_html_e('Prefer to talk?', 'pixelsprings'); ?></h2>
        <p><?php esc_html_e('Tell us about your team and the work you have in mind.', 'pixelsprings'); ?></p>
        <a class="button button-dark consultation-button" href="<?php echo esc_url(home_url('/book-a-call')); ?>"><?php _e('Book a Call <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></a>
        <a class="contact-email" href="mailto:contact@pixelsprings.com">contact@pixelsprings.com</a>
      </div>
      <form class="contact-form" data-testid="form-contact">
        <div class="field">
          <label for="contact-name"><?php esc_html_e('Name', 'pixelsprings'); ?></label>
          <input id="contact-name" name="name" autocomplete="name" required data-testid="input-contact-name" />
        </div>
        <div class="field">
          <label for="contact-email"><?php esc_html_e('Email', 'pixelsprings'); ?></label>
          <input id="contact-email" name="email" type="email" autocomplete="email" required data-testid="input-contact-email" />
        </div>
        <div class="field full">
          <label for="contact-company"><?php esc_html_e('Company / Website', 'pixelsprings'); ?> <span>(optional)</span></label>
          <input id="contact-company" name="company" autocomplete="organization" data-testid="input-contact-company" />
        </div>
        <div class="field full">
          <label for="contact-service"><?php esc_html_e('What can we help with?', 'pixelsprings'); ?></label>
          <select id="contact-service" name="service" data-testid="select-contact-service">
            <option value=""><?php esc_html_e('Choose an area (optional)', 'pixelsprings'); ?></option>
            <option value="Design"><?php esc_html_e('Design', 'pixelsprings'); ?></option>
            <option value="UI/UX"><?php esc_html_e('UI/UX', 'pixelsprings'); ?></option>
            <option value="Website"><?php esc_html_e('Website', 'pixelsprings'); ?></option>
            <option value="Development"><?php esc_html_e('Development', 'pixelsprings'); ?></option>
            <option value="E-commerce"><?php esc_html_e('E-commerce', 'pixelsprings'); ?></option>
            <option value="Something else"><?php esc_html_e('Something else', 'pixelsprings'); ?></option>
          </select>
        </div>
        <div class="field full">
          <label for="contact-message"><?php esc_html_e('Message', 'pixelsprings'); ?></label>
          <textarea id="contact-message" name="message" required data-testid="input-contact-message"></textarea>
        </div>
        <div class="form-bottom">
          <p class="form-note"><?php esc_html_e('This opens your email app with a draft addressed to contact@pixelsprings.com; you’ll need to send it from there.', 'pixelsprings'); ?></p>
          <button class="button button-dark" type="submit" data-testid="button-send-message"><?php _e('Send Message <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></button>
        </div>
      </form>
    </div>
  </section>
</main>

<?php get_footer(); ?>
