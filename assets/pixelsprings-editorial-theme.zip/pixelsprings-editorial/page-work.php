<?php
/**
 * Template Name: Work Page
 * The template for displaying the Work / Portfolio page (/work)
 *
 * @package Pixelsprings
 */
get_header();
$theme_uri = get_template_directory_uri();
?>

<main id="main" class="inner-main">
  <!-- PAGE HERO -->
  <section class="inner-hero inner-hero-left">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('Selected work', 'pixelsprings'); ?></div>
      <h1><?php _e('Good work speaks<br>for itself.', 'pixelsprings'); ?></h1>
      <p><?php esc_html_e('A selection of visual explorations and production work across branding, design, digital and web.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- INNER WORK GALLERY -->
  <section class="section work inner-work">
    <div class="wrap">
      <div class="work-header">
        <div>
          <div class="eyebrow"><?php esc_html_e('Visual studies', 'pixelsprings'); ?></div>
          <h2><?php esc_html_e('Ideas in progress.', 'pixelsprings'); ?></h2>
        </div>
        <p><?php esc_html_e('Visual studies — replace with approved work.', 'pixelsprings'); ?></p>
      </div>
      <p class="work-disclosure"><?php esc_html_e('The images below are temporary placeholders, not client projects or case studies.', 'pixelsprings'); ?></p>

      <div class="gallery" data-testid="gallery-projects">
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 1', 'pixelsprings'); ?>" data-testid="button-project-1">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-01.jpg'); ?>" alt="<?php esc_attr_e('Laptop and code on a bright design studio desk.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 2', 'pixelsprings'); ?>" data-testid="button-project-2">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-02.jpg'); ?>" alt="<?php esc_attr_e('A digital design system displayed on a desktop screen.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 3', 'pixelsprings'); ?>" data-testid="button-project-3">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-03.jpg'); ?>" alt="<?php esc_attr_e('Open sketchbook with early interface notes.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 4', 'pixelsprings'); ?>" data-testid="button-project-4">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-04.jpg'); ?>" alt="<?php esc_attr_e('Responsive website design viewed across laptop and phone.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 5', 'pixelsprings'); ?>" data-testid="button-project-5">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-05.jpg'); ?>" alt="<?php esc_attr_e('A team reviewing a digital project together.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 6', 'pixelsprings'); ?>" data-testid="button-project-6">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-06.jpg'); ?>" alt="<?php esc_attr_e('A creative team meeting around a conference table.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
      </div>
    </div>
  </section>

  <!-- CLOSING CTA -->
  <section class="final-cta inner-final-cta">
    <div class="eyebrow"><?php esc_html_e('Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></div>
    <h2><?php _e('Have something good<br><span class="cta-highlight">in the works?</span>', 'pixelsprings'); ?></h2>
    <div class="final-actions">
      <a class="button button-dark" href="<?php echo esc_url(home_url('/book-a-call')); ?>"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <a class="button button-light" href="<?php echo esc_url(home_url('/pricing')); ?>"><?php esc_html_e('View Pricing', 'pixelsprings'); ?></a>
    </div>
  </section>
</main>

<?php get_footer(); ?>
