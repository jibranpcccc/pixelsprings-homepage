<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Pixelsprings
 */
get_header(); ?>

<div class="not-found">
  <main id="main" class="wrap">
    <div class="eyebrow"><?php esc_html_e('404 / Page not found', 'pixelsprings'); ?></div>
    <h1><?php esc_html_e('That page isn’t here.', 'pixelsprings'); ?></h1>
    <p><?php esc_html_e('Head back to Pixelsprings and find your way from there.', 'pixelsprings'); ?></p>
    <a class="button button-dark" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Back to home', 'pixelsprings'); ?></a>
  </main>
</div>

<?php get_footer(); ?>
