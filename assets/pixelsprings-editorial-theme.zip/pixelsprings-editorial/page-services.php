<?php
/**
 * Template Name: Services Page
 * The template for displaying the Services page (/services)
 *
 * @package Pixelsprings
 */
get_header(); ?>

<main id="main" class="inner-main">
  <!-- PAGE HERO -->
  <section class="inner-hero inner-hero-left">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('What we do', 'pixelsprings'); ?></div>
      <h1><?php _e('Design and development,<br>all in one subscription.', 'pixelsprings'); ?></h1>
      <p><?php esc_html_e('A flexible production team for the creative, digital, and technical work that keeps your business moving.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- INNER CAPABILITIES -->
  <section class="section capabilities inner-capabilities">
    <div class="wrap">
      <div class="inner-cap-list">
        <article class="inner-capability">
          <div class="cap-label"><?php esc_html_e('01 / Design', 'pixelsprings'); ?></div>
          <h2><?php esc_html_e('Design that keeps your brand moving.', 'pixelsprings'); ?></h2>
          <p><?php esc_html_e('Ongoing visual production for the everyday moments that keep a brand consistent, recognizable, and ready for what comes next.', 'pixelsprings'); ?></p>
          <ul>
            <li><?php esc_html_e('Graphic design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Logo design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Branding', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Brand assets', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Packaging design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Print materials', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Social media creatives', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Advertising creatives', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Marketing collateral', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Presentation design', 'pixelsprings'); ?></li>
          </ul>
        </article>

        <article class="inner-capability">
          <div class="cap-label"><?php esc_html_e('02 / Digital', 'pixelsprings'); ?></div>
          <h2><?php esc_html_e('Digital experiences, from first frame to final screen.', 'pixelsprings'); ?></h2>
          <p><?php esc_html_e('Thoughtful digital design and implementation, from early interface work through responsive websites and updates.', 'pixelsprings'); ?></p>
          <ul>
            <li><?php esc_html_e('UI/UX design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Figma', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Website design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Landing pages', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Website redesigns', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('WordPress', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Webflow', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Responsive implementation', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Website updates', 'pixelsprings'); ?></li>
          </ul>
        </article>

        <article class="inner-capability">
          <div class="cap-label"><?php esc_html_e('03 / Development', 'pixelsprings'); ?></div>
          <h2><?php esc_html_e('The technical work behind the experience.', 'pixelsprings'); ?></h2>
          <p><?php esc_html_e('Scoped technical production for the functionality behind digital experiences. Larger builds move through clear milestones and active capacity.', 'pixelsprings'); ?></p>
          <ul>
            <li><?php esc_html_e('Custom coding', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Advanced WordPress', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('WooCommerce', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('E-commerce', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Custom functionality', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('API integrations', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Third-party integrations', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Front-end development', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Back-end development', 'pixelsprings'); ?></li>
          </ul>
        </article>
      </div>
      <p class="service-availability"><?php esc_html_e('Digital services are available with Pixel Flow and Pixel Forge. Development is included with Pixel Forge.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- HOW THE WORK FLOWS -->
  <section class="section">
    <div class="wrap rhythm">
      <div class="section-top">
        <div class="eyebrow"><?php esc_html_e('How the work flows', 'pixelsprings'); ?></div>
        <h2><?php _e('Great creative work,<br>without the complicated process.', 'pixelsprings'); ?></h2>
      </div>
      <div class="timeline">
        <article class="step">
          <div class="step-num">01</div>
          <div>
            <h3><?php esc_html_e('CHOOSE YOUR PLAN', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Choose the production capacity that fits your team.', 'pixelsprings'); ?></p>
          </div>
        </article>
        <article class="step">
          <div class="step-num">02</div>
          <div>
            <h3><?php esc_html_e('SHARE YOUR VISION', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Send requests whenever work comes up. We handle the production.', 'pixelsprings'); ?></p>
          </div>
        </article>
        <article class="step">
          <div class="step-num">03</div>
          <div>
            <h3><?php esc_html_e('REVIEW, REFINE & DELIVER', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Review the work, request revisions, approve, and move to the next request.', 'pixelsprings'); ?></p>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- CLEAR PATH FOR BIGGER WORK -->
  <section class="section project-scope">
    <div class="wrap scope-grid">
      <div>
        <div class="eyebrow"><?php esc_html_e('A clear path for bigger work', 'pixelsprings'); ?></div>
        <h2><?php esc_html_e('Big projects still fit the model.', 'pixelsprings'); ?></h2>
      </div>
      <div>
        <p><?php esc_html_e('Large websites, e-commerce builds and more complex development projects are handled through milestones within your active production capacity.', 'pixelsprings'); ?></p>
        <p><?php esc_html_e('A large project does not mean unlimited simultaneous production. We break the work into clear milestones and move them through the same production queue.', 'pixelsprings'); ?></p>
        <a class="text-link" href="<?php echo esc_url(home_url('/pricing')); ?>"><?php _e('See how capacity works <span aria-hidden="true">↗</span>', 'pixelsprings'); ?></a>
      </div>
    </div>
  </section>

  <!-- CLOSING CTA -->
  <section class="final-cta inner-final-cta">
    <div class="eyebrow"><?php esc_html_e('Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></div>
    <h2><?php _e('Ready to make more <span class="cta-highlight">room to create?</span>', 'pixelsprings'); ?></h2>
    <div class="final-actions">
      <a class="button button-dark" href="<?php echo esc_url(home_url('/book-a-call')); ?>"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <a class="button button-light" href="<?php echo esc_url(home_url('/pricing')); ?>"><?php esc_html_e('View Pricing', 'pixelsprings'); ?></a>
    </div>
  </section>
</main>

<?php get_footer(); ?>
