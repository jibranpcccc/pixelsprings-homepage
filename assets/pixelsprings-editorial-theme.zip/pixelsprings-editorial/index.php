<?php
/**
 * The main template file
 *
 * @package Pixelsprings
 */
get_header(); ?>

<main id="main" class="inner-main">
  <div class="wrap" style="padding: 80px 0;">
    <?php
    if (have_posts()) :
      while (have_posts()) : the_post();
        the_title('<h1>', '</h1>');
        the_content();
      endwhile;
    endif;
    ?>
  </div>
</main>

<?php get_footer(); ?>
