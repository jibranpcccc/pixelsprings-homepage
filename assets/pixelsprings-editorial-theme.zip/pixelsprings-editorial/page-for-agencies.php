<?php
/**
 * Template Name: For Agencies Page
 * The template for displaying the For Agencies page (/for-agencies)
 *
 * @package Pixelsprings
 */
get_header(); ?>

<main id="main" class="inner-main">
  <!-- PAGE HERO -->
  <section class="inner-hero inner-hero-left">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('For agencies', 'pixelsprings'); ?></div>
      <h1><?php _e('Your clients.<br><span class="agency-title-accent">Your brand.</span><br>Our production team.', 'pixelsprings'); ?></h1>
      <p><?php esc_html_e('A behind-the-scenes production partner for agencies that need more capacity without adding another full-time team.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- ROOM FOR THE NEXT BRIEF -->
  <section class="section agency-problem">
    <div class="wrap scope-grid">
      <div>
        <div class="eyebrow"><?php esc_html_e('Room for the next brief', 'pixelsprings'); ?></div>
        <h2><?php esc_html_e('Say yes to more work without stretching your team.', 'pixelsprings'); ?></h2>
      </div>
      <div>
        <p><?php esc_html_e('Agency workloads come in waves. Sometimes there is more design, development, web or production work than the internal team can comfortably handle.', 'pixelsprings'); ?></p>
        <p><?php esc_html_e('Pixelsprings provides flexible production capacity through a monthly subscription.', 'pixelsprings'); ?></p>
      </div>
    </div>
  </section>

  <!-- WE WORK BEHIND THE SCENES -->
  <section class="section agency inner-agency">
    <div class="wrap agency-grid">
      <div>
        <div class="eyebrow"><?php esc_html_e('Your behind-the-scenes advantage', 'pixelsprings'); ?></div>
        <h2><?php _e('We work<br><em>behind the scenes.</em>', 'pixelsprings'); ?></h2>
        <p class="agency-lede"><?php esc_html_e('Keep client relationships where they belong: with your agency. We fit into the production side of the work, in step with your team\'s direction.', 'pixelsprings'); ?></p>
        <div class="partnership-loop agency-flow" aria-label="<?php esc_attr_e('Agency production partnership flow', 'pixelsprings'); ?>">
          <div class="loop-kicker"><?php esc_html_e('THE PARTNERSHIP FLOW', 'pixelsprings'); ?></div>
          <div class="loop-flow">
            <div><b><?php esc_html_e('YOUR AGENCY', 'pixelsprings'); ?></b><span><?php esc_html_e('Strategy & relationships', 'pixelsprings'); ?></span></div>
            <i aria-hidden="true">→</i>
            <div><b><?php esc_html_e('PIXELSPRINGS', 'pixelsprings'); ?></b><span><?php esc_html_e('Creative & technical production', 'pixelsprings'); ?></span></div>
            <i aria-hidden="true">→</i>
            <div><b><?php esc_html_e('CLIENT OUTPUT', 'pixelsprings'); ?></b><span><?php esc_html_e('Delivered under your brand', 'pixelsprings'); ?></span></div>
          </div>
        </div>
      </div>
      <div class="agency-list">
        <article class="agency-item">
          <h3><?php esc_html_e('White-label friendly', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Work can be delivered without Pixelsprings branding unless agreed otherwise.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('Your client relationship', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Your agency remains client-facing and owns the relationship.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('Communication by your direction', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('No direct client communication unless your agency authorizes it.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('NDA-friendly', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('We can discuss the confidentiality requirements for your engagement.', 'pixelsprings'); ?></p>
        </article>
      </div>
    </div>
  </section>

  <!-- HOW THE PARTNERSHIP WORKS -->
  <section class="section agency-process" aria-labelledby="agency-process-title">
    <div class="wrap">
      <div class="agency-section-heading">
        <div class="eyebrow"><?php esc_html_e('A straightforward handoff', 'pixelsprings'); ?></div>
        <h2 id="agency-process-title"><?php esc_html_e('How the partnership works', 'pixelsprings'); ?></h2>
      </div>
      <div class="agency-steps">
        <article class="agency-step">
          <span class="agency-step-number">01</span>
          <h3><?php esc_html_e('You bring the brief', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Share the brief, references, guidelines, Figma files, and any useful assets or context.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-step">
          <span class="agency-step-number">02</span>
          <h3><?php esc_html_e('We handle production', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('The request enters the queue and is handled by the appropriate creative or technical specialist.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-step">
          <span class="agency-step-number">03</span>
          <h3><?php esc_html_e('You review the work', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Review the delivery and request revisions within the original scope.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-step">
          <span class="agency-step-number">04</span>
          <h3><?php esc_html_e('You deliver to your client', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Approved work returns to your agency, which remains the client-facing partner.', 'pixelsprings'); ?></p>
        </article>
      </div>
    </div>
  </section>

  <!-- BUILT FOR THE WAY AGENCIES WORK -->
  <section class="section agency-fit">
    <div class="wrap">
      <div class="agency-section-heading">
        <div class="eyebrow"><?php esc_html_e('Made to fit your team', 'pixelsprings'); ?></div>
        <h2><?php esc_html_e('Built for the way agencies work', 'pixelsprings'); ?></h2>
      </div>
      <div class="agency-benefits">
        <article class="agency-benefit">
          <span>01</span>
          <div>
            <h3><?php esc_html_e('Keep the client relationship yours', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Your agency stays in front; we support production behind the scenes.', 'pixelsprings'); ?></p>
          </div>
        </article>
        <article class="agency-benefit">
          <span>02</span>
          <div>
            <h3><?php esc_html_e('Add capacity without adding payroll', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Bring in production support when there is more work to move.', 'pixelsprings'); ?></p>
          </div>
        </article>
        <article class="agency-benefit">
          <span>03</span>
          <div>
            <h3><?php esc_html_e('One partner across disciplines', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Design, UI/UX, web, and development production in one place.', 'pixelsprings'); ?></p>
          </div>
        </article>
        <article class="agency-benefit">
          <span>04</span>
          <div>
            <h3><?php esc_html_e('Fit your existing workflow', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Work from your tools, files, guidelines, and established process.', 'pixelsprings'); ?></p>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- WHAT AGENCIES CAN SEND US -->
  <section class="section agency-offers">
    <div class="wrap">
      <div class="cap-intro">
        <div>
          <div class="eyebrow"><?php esc_html_e('What agencies can send us', 'pixelsprings'); ?></div>
          <h2><?php _e('A flexible range<br>of production work.', 'pixelsprings'); ?></h2>
        </div>
        <p><?php esc_html_e('Send the work that needs an extra pair of capable hands, across design, digital and development.', 'pixelsprings'); ?></p>
      </div>
      <ul class="agency-offer-list">
        <li><?php esc_html_e('Branding', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Graphic design', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Social creatives', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Marketing collateral', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('UI/UX', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Figma', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Landing pages', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Websites', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('WordPress', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Webflow', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Website updates', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Development', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('WooCommerce', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('E-commerce', 'pixelsprings'); ?></li>
        <li><?php esc_html_e('Custom functionality', 'pixelsprings'); ?></li>
      </ul>
    </div>
  </section>

  <!-- CAPACITY THAT FLEXES -->
  <section class="section agency-capacity">
    <div class="wrap scope-grid">
      <div>
        <div class="eyebrow"><?php esc_html_e('Capacity that flexes', 'pixelsprings'); ?></div>
        <h2><?php esc_html_e('Add capacity when the work is there.', 'pixelsprings'); ?></h2>
      </div>
      <div>
        <p><?php esc_html_e('Choose one monthly subscription for the level of production capacity that fits your team. Keep requests queued up and prioritize what needs attention.', 'pixelsprings'); ?></p>
        <p><?php esc_html_e('Your plan sets how many requests can be active at once: one with Spark, two with Flow, and three with Forge. Larger projects move through clear milestones within that capacity.', 'pixelsprings'); ?></p>
        <a class="text-link" href="<?php echo esc_url(home_url('/pricing')); ?>"><?php _e('Compare plans <span aria-hidden="true">↗</span>', 'pixelsprings'); ?></a>
      </div>
    </div>
  </section>

  <!-- AGENCY FAQ -->
  <section class="section">
    <div class="wrap faq">
      <div class="faq-title">
        <div class="eyebrow"><?php esc_html_e('For agency teams', 'pixelsprings'); ?></div>
        <h2><?php esc_html_e('Good to know.', 'pixelsprings'); ?></h2>
        <p><?php esc_html_e('A few practical details about working together.', 'pixelsprings'); ?></p>
      </div>
      <div class="faq-list" data-testid="faq-accordion">
        <?php
        $agency_faqs = array(
          array('Can you work completely white-label?', 'Yes. We can work behind the scenes, with no Pixelsprings branding unless agreed otherwise. Your agency remains client-facing and owns the relationship.'),
          array('Will you communicate directly with our clients?', 'Only when your agency authorizes it. Otherwise, we work with your team.'),
          array('Can you work under an NDA?', 'Yes. We are NDA-friendly; share the confidentiality requirements for your engagement.'),
          array('Can you follow our brand guidelines and workflow?', 'Yes. Share your guidelines, files, tools, and working context with the brief so production can fit your existing process.'),
          array('Can we submit multiple requests?', 'Yes. You can keep requests in the queue; your plan determines how many can be active at once.'),
          array('How many requests can be active?', 'A request remains active while it is being produced, reviewed, or revised. Spark includes one active request, Flow includes two, and Forge includes three.'),
          array('Can you take on web development?', 'Website and digital work are included with Flow and Forge. Development is included with Forge.'),
          array('How do large websites or e-commerce projects work?', 'Large websites, e-commerce projects, and complex development are handled in milestones within your active capacity.'),
          array('What if our workload changes?', 'Capacity is plan-based, and requests can remain queued. Contact Pixelsprings to discuss which current plan best fits your team.'),
        );
        foreach ($agency_faqs as $i => $faq): ?>
        <div class="faq-item">
          <h3 style="margin: 0;">
            <button class="faq-question" id="agency-faq-trigger-<?php echo esc_attr($i); ?>" type="button" aria-expanded="false" aria-controls="agency-faq-answer-<?php echo esc_attr($i); ?>" data-testid="button-faq-<?php echo esc_attr($i + 1); ?>">
              <span><?php echo esc_html($faq[0]); ?></span>
              <span class="faq-icon" aria-hidden="true">+</span>
            </button>
          </h3>
          <div class="faq-answer" id="agency-faq-answer-<?php echo esc_attr($i); ?>" role="region" aria-labelledby="agency-faq-trigger-<?php echo esc_attr($i); ?>" aria-hidden="true">
            <div><p><?php echo esc_html($faq[1]); ?></p></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- CLOSING CTA -->
  <section class="final-cta inner-final-cta">
    <div class="eyebrow"><?php esc_html_e('Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></div>
    <h2><?php _e('Need a production<br><span class="cta-highlight">partner?</span>', 'pixelsprings'); ?></h2>
    <div class="final-actions">
      <a class="button button-dark" href="<?php echo esc_url(home_url('/book-a-call')); ?>"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <a class="button button-light" href="<?php echo esc_url(home_url('/pricing')); ?>"><?php esc_html_e('View Pricing', 'pixelsprings'); ?></a>
    </div>
  </section>
</main>

<?php get_footer(); ?>
