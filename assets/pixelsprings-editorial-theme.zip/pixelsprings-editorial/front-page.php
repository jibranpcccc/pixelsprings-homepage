<?php
/**
 * Pixelsprings Editorial Theme Front Page
 *
 * @package Pixelsprings
 */
get_header();
$theme_uri = get_template_directory_uri();
?>

<main id="main">
  <!-- HERO SECTION -->
  <section class="hero" aria-labelledby="hero-title">
    <div class="hero-inner">
      <div class="eyebrow"><?php esc_html_e('Design + development, on subscription', 'pixelsprings'); ?></div>
      <h1 id="hero-title"><?php _e('Your creative team,<br><span>without the hiring headache.</span>', 'pixelsprings'); ?></h1>
      <p class="hero-copy"><?php esc_html_e('Design, web and development support for agencies and growing businesses — available through one simple monthly subscription.', 'pixelsprings'); ?></p>
      <div class="hero-actions">
        <a class="button button-dark" href="<?php echo esc_url(home_url('/pricing')); ?>" data-testid="link-view-plans"><?php _e('View Plans <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></a>
        <a class="button button-light" href="<?php echo esc_url(home_url('/book-a-call')); ?>" data-testid="link-book-call-hero"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      </div>
      <p class="hero-note"><?php _e('Unlimited requests <span aria-hidden="true">·</span> 1–3 active at a time <span aria-hidden="true">·</span> Cancel anytime', 'pixelsprings'); ?></p>

      <!-- 7-ITEM 3D CAROUSEL BOARD -->
      <div class="hero-board" role="img" aria-label="<?php esc_attr_e('A continuously moving strip featuring Branding, Graphic Design, UI / UX Design, Web Design, Development, E-commerce, and Packaging & Print.', 'pixelsprings'); ?>" data-testid="visual-hero-board">
        <div class="hero-marquee" aria-hidden="true">
          <div class="hero-track">
            <?php
            $carousel_items = array(
              array('img' => 'branding.jpg', 'label' => 'BRANDING'),
              array('img' => 'graphic-design.jpg', 'label' => 'GRAPHIC DESIGN'),
              array('img' => 'ui-ux.jpg', 'label' => 'UI / UX DESIGN'),
              array('img' => 'web-design.jpg', 'label' => 'WEB DESIGN'),
              array('img' => 'development.jpg', 'label' => 'DEVELOPMENT'),
              array('img' => 'ecommerce.jpg', 'label' => 'E-COMMERCE'),
              array('img' => 'packaging-print.jpg', 'label' => 'PACKAGING & PRINT'),
            );
            for ($loop = 0; $loop < 2; $loop++): ?>
            <div class="hero-track-group">
              <?php foreach ($carousel_items as $index => $item): ?>
              <div class="hero-tile hero-tile-<?php echo esc_attr($index + 1); ?>">
                <img src="<?php echo esc_url($theme_uri . '/assets/images/carousel/' . $item['img']); ?>" alt="" />
                <span class="hero-tile-label"><?php echo esc_html($item['label']); ?></span>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endfor; ?>
          </div>
        </div>
      </div>
      <div class="hero-rule" aria-hidden="true"></div>
    </div>
  </section>

  <!-- ROOM TO GROW -->
  <section class="section growth" id="services" aria-labelledby="growth-title">
    <div class="wrap">
      <div class="section-top">
        <div>
          <div class="eyebrow"><?php esc_html_e('Room to grow', 'pixelsprings'); ?></div>
          <h2 id="growth-title"><?php _e('More work shouldn\'t<br>mean more hiring.', 'pixelsprings'); ?></h2>
        </div>
        <p class="section-intro"><?php esc_html_e('Good work comes in waves. Add steady production support when the work is there — without changing the shape of your team.', 'pixelsprings'); ?></p>
      </div>
      <div class="growth-points">
        <article class="growth-point">
          <span class="index"><?php esc_html_e('01 / CAPACITY', 'pixelsprings'); ?></span>
          <h3><?php esc_html_e('More capacity', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Add production capacity without adding another full-time hire.', 'pixelsprings'); ?></p>
        </article>
        <article class="growth-point">
          <span class="index"><?php esc_html_e('02 / RANGE', 'pixelsprings'); ?></span>
          <h3><?php esc_html_e('One flexible team', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Design, web, and development support in one subscription.', 'pixelsprings'); ?></p>
        </article>
        <article class="growth-point">
          <span class="index"><?php esc_html_e('03 / RHYTHM', 'pixelsprings'); ?></span>
          <h3><?php esc_html_e('Predictable production', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('A simple monthly model built for ongoing work.', 'pixelsprings'); ?></p>
        </article>
      </div>
    </div>
  </section>

  <!-- HOW IT WORKS -->
  <section class="section" aria-labelledby="rhythm-title">
    <div class="wrap rhythm">
      <div class="section-top">
        <div class="eyebrow"><?php esc_html_e('How it works', 'pixelsprings'); ?></div>
        <h2 id="rhythm-title"><?php _e('GREAT CREATIVE<br>WORK, WITHOUT THE<br>COMPLICATED PROCESS', 'pixelsprings'); ?></h2>
      </div>
      <div class="timeline" data-testid="production-timeline">
        <article class="step" data-testid="step-production-01">
          <div class="step-num">01</div>
          <div>
            <h3><?php esc_html_e('CHOOSE YOUR PLAN', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Choose the production capacity that fits your team.', 'pixelsprings'); ?></p>
          </div>
        </article>
        <article class="step" data-testid="step-production-02">
          <div class="step-num">02</div>
          <div>
            <h3><?php esc_html_e('SHARE YOUR VISION', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Send requests whenever work comes up. We handle the production.', 'pixelsprings'); ?></p>
          </div>
        </article>
        <article class="step" data-testid="step-production-03">
          <div class="step-num">03</div>
          <div>
            <h3><?php esc_html_e('REVIEW, REFINE & DELIVER', 'pixelsprings'); ?></h3>
            <p><?php esc_html_e('Review the work, request revisions, approve, and move to the next request.', 'pixelsprings'); ?></p>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- OUR CAPABILITIES -->
  <section class="section capabilities" id="capabilities" aria-labelledby="capabilities-title">
    <div class="wrap">
      <div class="cap-intro">
        <div>
          <div class="eyebrow"><?php esc_html_e('Our capabilities', 'pixelsprings'); ?></div>
          <h2 id="capabilities-title"><?php _e('A broad production<br>practice.', 'pixelsprings'); ?></h2>
        </div>
        <p><?php esc_html_e('One thoughtful team across the work that makes a brand visible, useful, and ready to grow.', 'pixelsprings'); ?></p>
      </div>
      <div class="cap-list">
        <article class="capability" data-testid="capability-design">
          <div class="cap-label"><?php esc_html_e('Discipline 01', 'pixelsprings'); ?></div>
          <h3><?php esc_html_e('Design', 'pixelsprings'); ?></h3>
          <ul>
            <li><?php esc_html_e('Graphic design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Logo design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Branding', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Packaging', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Print materials', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Social media creatives', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Advertising creatives', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Marketing collateral', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Presentation design', 'pixelsprings'); ?></li>
          </ul>
        </article>
        <article class="capability" data-testid="capability-digital">
          <div class="cap-label"><?php esc_html_e('Discipline 02', 'pixelsprings'); ?></div>
          <h3><?php esc_html_e('Digital', 'pixelsprings'); ?></h3>
          <ul>
            <li><?php esc_html_e('UI/UX', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Figma', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Website design', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Landing pages', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('WordPress', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Webflow', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Website redesigns', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Website updates', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Responsive implementation', 'pixelsprings'); ?></li>
          </ul>
        </article>
        <article class="capability" data-testid="capability-development">
          <div class="cap-label"><?php esc_html_e('Discipline 03', 'pixelsprings'); ?></div>
          <h3><?php esc_html_e('Development', 'pixelsprings'); ?></h3>
          <ul>
            <li><?php esc_html_e('Custom coding', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Advanced WordPress', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('WooCommerce', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('E-commerce', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Custom functionality', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('API / integrations', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Third-party integrations', 'pixelsprings'); ?></li>
            <li><?php esc_html_e('Front-end / back-end development', 'pixelsprings'); ?></li>
          </ul>
        </article>
      </div>
    </div>
  </section>

  <!-- BEHIND-THE-SCENES ADVANTAGE -->
  <section class="section agency" id="agencies" aria-labelledby="agency-title">
    <div class="wrap agency-grid">
      <div>
        <div class="eyebrow"><?php esc_html_e('Your behind-the-scenes advantage', 'pixelsprings'); ?></div>
        <h2 id="agency-title"><?php _e('Your clients.<br><em>Your brand.</em><br>Our production team.', 'pixelsprings'); ?></h2>
        <p class="agency-lede"><?php esc_html_e('A production partner that fits quietly into your agency — so you can say yes to good work and keep the relationship where it belongs: with you.', 'pixelsprings'); ?></p>
      </div>
      <div class="agency-list">
        <div class="partnership-loop" aria-label="<?php esc_attr_e('The seamless partnership loop', 'pixelsprings'); ?>">
          <div class="loop-kicker"><?php esc_html_e('THE SEAMLESS PARTNERSHIP LOOP', 'pixelsprings'); ?></div>
          <div class="loop-flow">
            <div><b><?php esc_html_e('YOUR AGENCY', 'pixelsprings'); ?></b><span><?php esc_html_e('Strategy & relationships', 'pixelsprings'); ?></span></div>
            <i aria-hidden="true">→</i>
            <div><b><?php esc_html_e('PIXELSPRINGS', 'pixelsprings'); ?></b><span><?php esc_html_e('Creative & technical production', 'pixelsprings'); ?></span></div>
            <i aria-hidden="true">→</i>
            <div><b><?php esc_html_e('CLIENT OUTPUT', 'pixelsprings'); ?></b><span><?php esc_html_e('Delivered under your brand', 'pixelsprings'); ?></span></div>
          </div>
        </div>
        <article class="agency-item">
          <h3><?php esc_html_e('White-label friendly', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('We work behind the scenes so your client relationship stays yours.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('No direct client communication', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('We do not communicate directly with your clients unless you specifically authorize it.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('No Pixelsprings branding', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Deliverables remain under your brand unless otherwise agreed.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('NDA-friendly', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('We understand confidential agency relationships and client work.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('Client relationship stays yours', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('You remain the client-facing team.', 'pixelsprings'); ?></p>
        </article>
        <article class="agency-item">
          <h3><?php esc_html_e('Design + web + development', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('One production partner across multiple disciplines.', 'pixelsprings'); ?></p>
        </article>
      </div>
    </div>
  </section>

  <!-- PORTFOLIO WORK -->
  <section class="section work" id="work" aria-labelledby="work-title">
    <div class="wrap">
      <div class="work-header">
        <div>
          <div class="eyebrow"><?php esc_html_e('Portfolio', 'pixelsprings'); ?></div>
          <h2 id="work-title"><?php esc_html_e('Creative possibilities.', 'pixelsprings'); ?></h2>
        </div>
        <p><?php esc_html_e('Temporary image placeholders — replace these with your own work.', 'pixelsprings'); ?></p>
      </div>
      <div class="gallery" data-testid="gallery-projects">
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 1', 'pixelsprings'); ?>" data-testid="button-project-1">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-01.jpg'); ?>" alt="<?php esc_attr_e('Laptop and code on a bright design studio desk.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 2', 'pixelsprings'); ?>" data-testid="button-project-2">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-02.jpg'); ?>" alt="<?php esc_attr_e('A digital design system displayed on a desktop screen.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 3', 'pixelsprings'); ?>" data-testid="button-project-3">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-03.jpg'); ?>" alt="<?php esc_attr_e('Open sketchbook with early interface notes.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 4', 'pixelsprings'); ?>" data-testid="button-project-4">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-04.jpg'); ?>" alt="<?php esc_attr_e('Responsive website design viewed across laptop and phone.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 5', 'pixelsprings'); ?>" data-testid="button-project-5">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-05.jpg'); ?>" alt="<?php esc_attr_e('A team reviewing a digital project together.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
        <button class="project" type="button" aria-label="<?php esc_attr_e('View image 6', 'pixelsprings'); ?>" data-testid="button-project-6">
          <div class="project-art"><img src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-06.jpg'); ?>" alt="<?php esc_attr_e('A creative team meeting around a conference table.', 'pixelsprings'); ?>" loading="lazy" /></div>
        </button>
      </div>
    </div>
  </section>

  <!-- PRICING TABLE -->
  <section class="section pricing" id="pricing" aria-labelledby="pricing-title">
    <div class="wrap">
      <div class="pricing-heading">
        <div class="eyebrow"><?php esc_html_e('Pricing', 'pixelsprings'); ?></div>
        <h2 id="pricing-title"><?php esc_html_e('Choose the production capacity that fits your team.', 'pixelsprings'); ?></h2>
      </div>
      <div class="pricing-scroll" role="region" aria-label="<?php esc_attr_e('Pricing comparison; scroll horizontally to compare all plans', 'pixelsprings'); ?>" tabindex="0" data-testid="pricing-comparison">
        <div class="price-table">
          <div class="price-head">
            <div class="price-plan"><span class="eyebrow"><?php esc_html_e('Monthly subscription', 'pixelsprings'); ?></span></div>
            <div class="price-plan">
              <h3>PIXEL SPARK</h3>
              <div class="price">$799<small>/month</small></div>
              <p><?php esc_html_e('1 active request', 'pixelsprings'); ?></p>
              <a class="button button-light" href="mailto:contact@pixelsprings.com?subject=Pixel%20Spark%20plan" data-testid="link-plan-1"><?php esc_html_e('Choose Spark', 'pixelsprings'); ?></a>
            </div>
            <div class="price-plan featured">
              <h3>PIXEL FLOW</h3>
              <div class="price">$1,499<small>/month</small></div>
              <p><?php esc_html_e('2 active requests', 'pixelsprings'); ?></p>
              <a class="button button-dark" href="mailto:contact@pixelsprings.com?subject=Pixel%20Flow%20plan" data-testid="link-plan-2"><?php esc_html_e('Choose Flow', 'pixelsprings'); ?></a>
            </div>
            <div class="price-plan">
              <h3>PIXEL FORGE</h3>
              <div class="price">$2,499<small>/month</small></div>
              <p><?php esc_html_e('3 active requests', 'pixelsprings'); ?></p>
              <a class="button button-light" href="mailto:contact@pixelsprings.com?subject=Pixel%20Forge%20plan" data-testid="link-plan-3"><?php esc_html_e('Choose Forge', 'pixelsprings'); ?></a>
            </div>
          </div>

          <!-- DESIGN CATEGORY -->
          <div class="price-row category"><span>DESIGN</span><span></span><span></span><span></span></div>
          <?php
          $design_items = array(
            'Graphic design' => array(true, true, true),
            'Logo design' => array(true, true, true),
            'Branding' => array(true, true, true),
            'Packaging' => array(true, true, true),
            'Print materials' => array(true, true, true),
            'Social media creatives' => array(true, true, true),
            'Advertising creatives' => array(true, true, true),
            'Marketing collateral' => array(true, true, true),
            'Presentation design' => array(true, true, true),
          );
          $row = 1;
          foreach ($design_items as $item => $avail): ?>
          <div class="price-row" data-testid="row-feature-design-<?php echo esc_attr($row++); ?>">
            <span><?php echo esc_html($item); ?></span>
            <?php foreach ($avail as $inc): ?>
            <span class="<?php echo $inc ? 'yes' : 'not-yet'; ?>" aria-label="<?php echo $inc ? 'Included' : 'Not included'; ?>"><?php echo $inc ? '✓' : '—'; ?></span>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>

          <!-- DIGITAL CATEGORY -->
          <div class="price-row category"><span>DIGITAL</span><span></span><span></span><span></span></div>
          <?php
          $digital_items = array(
            'UI/UX' => array(false, true, true),
            'Figma' => array(false, true, true),
            'Website design' => array(false, true, true),
            'Landing pages' => array(false, true, true),
            'WordPress' => array(false, true, true),
            'Webflow' => array(false, true, true),
            'Website redesigns' => array(false, true, true),
            'Website updates' => array(false, true, true),
            'Responsive implementation' => array(false, true, true),
          );
          $row = 1;
          foreach ($digital_items as $item => $avail): ?>
          <div class="price-row" data-testid="row-feature-digital-<?php echo esc_attr($row++); ?>">
            <span><?php echo esc_html($item); ?></span>
            <?php foreach ($avail as $inc): ?>
            <span class="<?php echo $inc ? 'yes' : 'not-yet'; ?>" aria-label="<?php echo $inc ? 'Included' : 'Not included'; ?>"><?php echo $inc ? '✓' : '—'; ?></span>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>

          <!-- DEVELOPMENT CATEGORY -->
          <div class="price-row category"><span>DEVELOPMENT</span><span></span><span></span><span></span></div>
          <?php
          $dev_items = array(
            'Custom coding' => array(false, false, true),
            'Advanced WordPress' => array(false, false, true),
            'WooCommerce' => array(false, false, true),
            'E-commerce' => array(false, false, true),
            'Custom functionality' => array(false, false, true),
            'API / integrations' => array(false, false, true),
            'Third-party integrations' => array(false, false, true),
            'Front-end / back-end development' => array(false, false, true),
          );
          $row = 1;
          foreach ($dev_items as $item => $avail): ?>
          <div class="price-row" data-testid="row-feature-development-<?php echo esc_attr($row++); ?>">
            <span><?php echo esc_html($item); ?></span>
            <?php foreach ($avail as $inc): ?>
            <span class="<?php echo $inc ? 'yes' : 'not-yet'; ?>" aria-label="<?php echo $inc ? 'Included' : 'Not included'; ?>"><?php echo $inc ? '✓' : '—'; ?></span>
            <?php endforeach; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <p class="pricing-scroll-hint"><?php _e('Swipe to compare all three plans <span aria-hidden="true">→</span>', 'pixelsprings'); ?></p>
      <p class="pricing-note"><strong><?php esc_html_e('One note on scope:', 'pixelsprings'); ?></strong> <?php esc_html_e('Large or complex projects are handled through milestones within your active production capacity.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- FAQ ACCORDION -->
  <section class="section" id="faq" aria-labelledby="faq-title">
    <div class="wrap faq">
      <div class="faq-title">
        <div class="eyebrow"><?php esc_html_e('A few good questions', 'pixelsprings'); ?></div>
        <h2 id="faq-title"><?php esc_html_e('Good to know.', 'pixelsprings'); ?></h2>
        <p><?php esc_html_e('A little more on how the work works.', 'pixelsprings'); ?></p>
      </div>
      <div class="faq-list" data-testid="faq-accordion">
        <?php
        $faqs = array(
          array('What does unlimited requests mean?', 'You can keep adding work to your request queue and prioritize what matters most. Your plan sets how many requests can be active at once.'),
          array('How many requests can be active?', 'Pixel Spark includes one active request, Pixel Flow includes two, and Pixel Forge includes three.'),
          array('What counts as a request?', 'A request is a clearly defined deliverable, such as a design asset, a web page, or a scoped development task. Larger or connected work can be organized into milestones.'),
          array('How do large websites work?', 'Large or complex projects are handled through milestones within your active production capacity.'),
          array('How do revisions work?', 'Review the work, share your feedback, and request revisions within the original scope.'),
          array('Can I pause or cancel?', 'You can cancel anytime. If you are looking to pause rather than cancel, contact us and we can clarify the available options.'),
          array('Do you work with agencies?', 'Yes. Pixelsprings is set up to support agency teams with flexible design, digital, and development production.'),
          array('Can you work white-label?', 'Yes. We work behind the scenes so your client relationship stays yours. Deliverables remain under your brand unless otherwise agreed.'),
          array('Do you communicate directly with my clients?', 'Only when you specifically authorize it. Otherwise, we work with your team behind the scenes.'),
          array('What if I need development?', 'Development is included with Pixel Forge. Pixel Spark and Pixel Flow focus on design and digital services.'),
          array('What tools do you use?', 'The right tools depend on your workflow and project. Tell us what your team already uses and we can confirm the fit before work begins.'),
        );
        foreach ($faqs as $i => $faq): ?>
        <div class="faq-item">
          <h3 style="margin: 0;">
            <button class="faq-question" id="faq-trigger-<?php echo esc_attr($i); ?>" type="button" aria-expanded="false" aria-controls="faq-answer-<?php echo esc_attr($i); ?>" data-testid="button-faq-<?php echo esc_attr($i + 1); ?>">
              <span><?php echo esc_html($faq[0]); ?></span>
              <span class="faq-icon" aria-hidden="true">+</span>
            </button>
          </h3>
          <div class="faq-answer" id="faq-answer-<?php echo esc_attr($i); ?>" role="region" aria-labelledby="faq-trigger-<?php echo esc_attr($i); ?>" aria-hidden="true">
            <div><p><?php echo esc_html($faq[1]); ?></p></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- CONTACT SECTION -->
  <section class="section contact" id="contact" aria-labelledby="contact-title">
    <div class="wrap contact-grid">
      <div class="contact-title">
        <div class="eyebrow"><?php esc_html_e('Contact', 'pixelsprings'); ?></div>
        <h2 id="contact-title"><?php esc_html_e('Have a question?', 'pixelsprings'); ?></h2>
        <p><?php esc_html_e('Share a little about the work you have in mind.', 'pixelsprings'); ?></p>
        <a class="button button-dark consultation-button" href="<?php echo esc_url(home_url('/book-a-call')); ?>" data-testid="link-free-consultation"><?php _e('Book a Free Consultation <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></a>
        <a class="contact-email" href="mailto:contact@pixelsprings.com" data-testid="link-contact-email">contact@pixelsprings.com</a>
      </div>
      <form class="contact-form" data-testid="form-contact">
        <div class="field">
          <label for="contact-name"><?php esc_html_e('Name', 'pixelsprings'); ?></label>
          <input id="contact-name" name="name" autocomplete="name" required data-testid="input-contact-name" />
        </div>
        <div class="field">
          <label for="contact-email"><?php esc_html_e('Email', 'pixelsprings'); ?></label>
          <input id="contact-email" name="email" type="email" autocomplete="email" required data-testid="input-contact-email" />
        </div>
        <div class="field full">
          <label for="contact-company"><?php esc_html_e('Company / Website', 'pixelsprings'); ?> <span>(optional)</span></label>
          <input id="contact-company" name="company" autocomplete="organization" data-testid="input-contact-company" />
        </div>
        <div class="field full">
          <label for="contact-service"><?php esc_html_e('What can we help with?', 'pixelsprings'); ?></label>
          <select id="contact-service" name="service" data-testid="select-contact-service">
            <option value=""><?php esc_html_e('Choose an area (optional)', 'pixelsprings'); ?></option>
            <option value="Design"><?php esc_html_e('Design', 'pixelsprings'); ?></option>
            <option value="UI/UX"><?php esc_html_e('UI/UX', 'pixelsprings'); ?></option>
            <option value="Website"><?php esc_html_e('Website', 'pixelsprings'); ?></option>
            <option value="Development"><?php esc_html_e('Development', 'pixelsprings'); ?></option>
            <option value="E-commerce"><?php esc_html_e('E-commerce', 'pixelsprings'); ?></option>
            <option value="Something else"><?php esc_html_e('Something else', 'pixelsprings'); ?></option>
          </select>
        </div>
        <div class="field full">
          <label for="contact-message"><?php esc_html_e('Message', 'pixelsprings'); ?></label>
          <textarea id="contact-message" name="message" required data-testid="input-contact-message"></textarea>
        </div>
        <div class="form-bottom">
          <p class="form-note"><?php esc_html_e('This opens your email app with a draft addressed to contact@pixelsprings.com; you\'ll need to send it from there.', 'pixelsprings'); ?></p>
          <button class="button button-dark" type="submit" data-testid="button-send-message"><?php _e('Send Message <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></button>
        </div>
      </form>
    </div>
  </section>

  <!-- FINAL CTA -->
  <section class="final-cta" aria-labelledby="final-cta-title">
    <div class="eyebrow"><?php esc_html_e('Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></div>
    <h2 id="final-cta-title"><?php _e('Let\'s make more <span class="cta-highlight">room to create.</span>', 'pixelsprings'); ?></h2>
    <div class="final-actions">
      <a class="button button-dark" href="<?php echo esc_url(home_url('/book-a-call')); ?>" data-testid="link-book-call-final"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <a class="button button-light" href="<?php echo esc_url(home_url('/contact')); ?>" data-testid="link-send-message-final"><?php esc_html_e('Send a Message', 'pixelsprings'); ?></a>
    </div>
  </section>
</main>

<?php get_footer(); ?>
