<?php
/**
 * Pixelsprings Editorial Theme Header
 *
 * @package Pixelsprings
 */
$theme_uri = get_template_directory_uri();
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <link rel="icon" type="image/svg+xml" href="<?php echo esc_url($theme_uri . '/assets/images/favicon.svg'); ?>">
  <link rel="preconnect" href="https://api.fontshare.com">
  <link rel="preconnect" href="https://cdn.fontshare.com" crossorigin>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="top">
  <a class="skip-link" href="#main"><?php esc_html_e('Skip to content', 'pixelsprings'); ?></a>

  <header class="site-header">
    <div class="header-inner">
      <a class="wordmark" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Pixelsprings — home', 'pixelsprings'); ?>" data-testid="link-brand">
        <img class="wordmark-logo" src="<?php echo esc_url($theme_uri . '/assets/images/pixelsprings-logo.png'); ?>" alt="Pixelsprings" />
      </a>
      <nav class="nav-links" aria-label="<?php esc_attr_e('Main navigation', 'pixelsprings'); ?>">
        <a href="<?php echo esc_url(home_url('/services')); ?>" data-testid="link-nav-services"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/pricing')); ?>" data-testid="link-nav-pricing"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/work')); ?>" data-testid="link-nav-work"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/for-agencies')); ?>" data-testid="link-nav-for-agencies"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" data-testid="link-nav-contact"><?php esc_html_e('Contact', 'pixelsprings'); ?></a>
      </nav>
      <a class="nav-cta" href="<?php echo esc_url(home_url('/book-a-call')); ?>" data-testid="link-book-call-nav"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <button class="mobile-toggle" id="mobileMenuToggle" type="button" aria-label="<?php esc_attr_e('Open navigation menu', 'pixelsprings'); ?>" aria-expanded="false" aria-controls="mobile-navigation" data-testid="button-mobile-menu">☰</button>
    </div>
    <nav id="mobile-navigation" class="mobile-panel" aria-label="<?php esc_attr_e('Mobile navigation', 'pixelsprings'); ?>" style="display: none;" data-testid="mobile-navigation">
      <a href="<?php echo esc_url(home_url('/services')); ?>"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/pricing')); ?>"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/work')); ?>"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/for-agencies')); ?>"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact', 'pixelsprings'); ?></a>
      <a class="button button-dark" href="<?php echo esc_url(home_url('/book-a-call')); ?>"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
    </nav>
  </header>
