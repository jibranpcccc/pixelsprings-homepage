<?php
/**
 * Pixelsprings Editorial Theme Functions and Definitions
 *
 * @package Pixelsprings
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('PIXELSPRINGS_VERSION', '2.0.1');

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function pixelsprings_setup() {
    load_theme_textdomain('pixelsprings', get_template_directory() . '/languages');

    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(1200, 800, true);

    register_nav_menus(array(
        'primary' => esc_html__('Primary Header Navigation', 'pixelsprings'),
        'footer'  => esc_html__('Footer Navigation', 'pixelsprings'),
    ));

    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
}
add_action('after_setup_theme', 'pixelsprings_setup');

/**
 * Enqueue scripts and styles.
 */
function pixelsprings_scripts() {
    // Web Fonts (Satoshi from Fontshare and Plus Jakarta Sans from Google Fonts)
    wp_enqueue_style('fontshare-satoshi', 'https://api.fontshare.com/v2/css?f[]=satoshi@400,500,600,700&display=swap', array(), null);
    wp_enqueue_style('google-jakarta', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap', array(), null);

    // Main Compiled & Normalized CSS
    wp_enqueue_style('pixelsprings-main', get_template_directory_uri() . '/assets/css/main.css', array(), PIXELSPRINGS_VERSION);
    wp_enqueue_style('pixelsprings-style', get_stylesheet_uri(), array('pixelsprings-main'), PIXELSPRINGS_VERSION);

    // Theme Core JavaScript
    wp_enqueue_script('pixelsprings-script', get_template_directory_uri() . '/assets/js/pixelsprings.js', array(), PIXELSPRINGS_VERSION, true);
}
add_action('wp_enqueue_scripts', 'pixelsprings_scripts');

/**
 * Customize Document Title to match Replit specifications
 */
function pixelsprings_document_title_parts($title) {
    if (is_front_page()) {
        $title['title'] = 'Pixelsprings — Design + Development, on Subscription';
        unset($title['site']);
        unset($title['tagline']);
    } elseif (is_page('services')) {
        $title['title'] = 'Services — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('pricing')) {
        $title['title'] = 'Pricing — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('work')) {
        $title['title'] = 'Work — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('for-agencies')) {
        $title['title'] = 'For Agencies — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('book-a-call')) {
        $title['title'] = 'Book a Call — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('contact')) {
        $title['title'] = 'Contact — Pixelsprings';
        unset($title['site']);
    }
    return $title;
}
add_filter('document_title_parts', 'pixelsprings_document_title_parts');

/**
 * Automatically initialize pages, navigation, and reading settings on theme activation.
 */
function pixelsprings_auto_initialize_theme() {
    $pages_to_create = array(
        'home' => array(
            'title'    => 'Home',
            'slug'     => 'home',
            'template' => 'front-page.php',
            'content'  => '',
        ),
        'services' => array(
            'title'    => 'Services',
            'slug'     => 'services',
            'template' => 'page-services.php',
            'content'  => '',
        ),
        'pricing' => array(
            'title'    => 'Pricing',
            'slug'     => 'pricing',
            'template' => 'page-pricing.php',
            'content'  => '',
        ),
        'work' => array(
            'title'    => 'Work',
            'slug'     => 'work',
            'template' => 'page-work.php',
            'content'  => '',
        ),
        'for-agencies' => array(
            'title'    => 'For Agencies',
            'slug'     => 'for-agencies',
            'template' => 'page-for-agencies.php',
            'content'  => '',
        ),
        'book-a-call' => array(
            'title'    => 'Book a Call',
            'slug'     => 'book-a-call',
            'template' => 'page-book-a-call.php',
            'content'  => '',
        ),
        'contact' => array(
            'title'    => 'Contact',
            'slug'     => 'contact',
            'template' => 'page-contact.php',
            'content'  => '',
        ),
    );

    $created_page_ids = array();

    foreach ($pages_to_create as $key => $page_info) {
        $existing = get_page_by_path($page_info['slug']);
        if (!$existing) {
            $page_id = wp_insert_post(array(
                'post_title'     => $page_info['title'],
                'post_name'      => $page_info['slug'],
                'post_status'    => 'publish',
                'post_type'      => 'page',
                'post_content'   => $page_info['content'],
                'comment_status' => 'closed',
            ));
            if ($page_id && !is_wp_error($page_id)) {
                if (!empty($page_info['template'])) {
                    update_post_meta($page_id, '_wp_page_template', $page_info['template']);
                }
                $created_page_ids[$key] = $page_id;
            }
        } else {
            $created_page_ids[$key] = $existing->ID;
            if (!empty($page_info['template'])) {
                update_post_meta($existing->ID, '_wp_page_template', $page_info['template']);
            }
            if ($existing->post_status !== 'publish') {
                wp_update_post(array('ID' => $existing->ID, 'post_status' => 'publish'));
            }
        }
    }

    // Set static front page
    if (!empty($created_page_ids['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $created_page_ids['home']);
    }

    // Ensure pretty permalinks
    if (get_option('permalink_structure') === '') {
        update_option('permalink_structure', '/%postname%/');
    }
    flush_rewrite_rules();

    // Create Primary Menu if not already set
    $menu_name = 'Pixelsprings Primary Menu';
    $menu_exists = wp_get_nav_menu_object($menu_name);

    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);

        $nav_items = array(
            array('title' => 'Services', 'url' => home_url('/services')),
            array('title' => 'Pricing', 'url' => home_url('/pricing')),
            array('title' => 'Work', 'url' => home_url('/work')),
            array('title' => 'For Agencies', 'url' => home_url('/for-agencies')),
            array('title' => 'Contact', 'url' => home_url('/contact')),
            array('title' => 'Book a Call', 'url' => home_url('/book-a-call')),
        );

        foreach ($nav_items as $item) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title'   => $item['title'],
                'menu-item-url'     => $item['url'],
                'menu-item-status'  => 'publish',
            ));
        }

        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_id;
        $locations['footer']  = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}
add_action('after_switch_theme', 'pixelsprings_auto_initialize_theme');
