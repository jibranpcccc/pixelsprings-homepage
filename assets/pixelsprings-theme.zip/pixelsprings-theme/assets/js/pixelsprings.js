/**
 * Pixelsprings Theme JavaScript Engine
 * Handles Mobile Menu, FAQ Accordion, Lightbox Modal, and Contact Toast
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    // 1. Mobile Navigation Toggle
    var menuBtn = document.getElementById('mobileMenuToggle');
    var mobileNav = document.getElementById('mobile-navigation');
    if (menuBtn && mobileNav) {
      menuBtn.addEventListener('click', function () {
        var isOpen = mobileNav.style.display !== 'none';
        mobileNav.style.display = isOpen ? 'none' : 'flex';
        menuBtn.textContent = isOpen ? '☰' : '×';
        menuBtn.setAttribute('aria-expanded', !isOpen);
      });
      mobileNav.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          mobileNav.style.display = 'none';
          menuBtn.textContent = '☰';
          menuBtn.setAttribute('aria-expanded', 'false');
        });
      });
    }

    // 2. FAQ Accordion
    var faqButtons = document.querySelectorAll('.faq-question');
    faqButtons.forEach(function (btn, index) {
      btn.addEventListener('click', function () {
        var isExpanded = btn.getAttribute('aria-expanded') === 'true';
        var answer = document.getElementById('faq-answer-' + index);

        // Collapse all others
        faqButtons.forEach(function (otherBtn, otherIndex) {
          otherBtn.setAttribute('aria-expanded', 'false');
          var otherAnswer = document.getElementById('faq-answer-' + otherIndex);
          if (otherAnswer) {
            otherAnswer.classList.remove('open');
            otherAnswer.setAttribute('aria-hidden', 'true');
          }
        });

        // Toggle clicked item
        if (!isExpanded && answer) {
          btn.setAttribute('aria-expanded', 'true');
          answer.classList.add('open');
          answer.setAttribute('aria-hidden', 'false');
        }
      });
    });

    // 3. Portfolio Lightbox Modal
    var lightbox = document.getElementById('projectLightbox');
    var lightboxImg = document.getElementById('lightboxImg');
    var lightboxCaption = document.getElementById('lightboxCaption');
    var lightboxClose = document.getElementById('lightboxClose');
    var lightboxPrev = document.getElementById('lightboxPrev');
    var lightboxNext = document.getElementById('lightboxNext');
    var projectButtons = document.querySelectorAll('.project');

    var projectData = [];
    projectButtons.forEach(function (btn) {
      var img = btn.querySelector('img');
      projectData.push({
        src: img ? img.getAttribute('src') : '',
        alt: img ? img.getAttribute('alt') : '',
        caption: btn.getAttribute('data-caption') || (img ? img.getAttribute('alt') : 'Portfolio Work')
      });
    });

    var currentIndex = 0;

    function openLightbox(index) {
      if (!projectData.length) return;
      currentIndex = (index + projectData.length) % projectData.length;
      if (lightboxImg) {
        lightboxImg.src = projectData[currentIndex].src;
        lightboxImg.alt = projectData[currentIndex].alt;
      }
      if (lightboxCaption) {
        lightboxCaption.textContent = projectData[currentIndex].caption;
      }
      if (lightbox) {
        lightbox.style.display = 'grid';
        document.body.style.overflow = 'hidden';
      }
    }

    function closeLightbox() {
      if (lightbox) {
        lightbox.style.display = 'none';
        document.body.style.overflow = '';
      }
    }

    projectButtons.forEach(function (btn, idx) {
      btn.addEventListener('click', function () {
        openLightbox(idx);
      });
    });

    if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
    if (lightboxPrev) lightboxPrev.addEventListener('click', function (e) { e.stopPropagation(); openLightbox(currentIndex - 1); });
    if (lightboxNext) lightboxNext.addEventListener('click', function (e) { e.stopPropagation(); openLightbox(currentIndex + 1); });

    if (lightbox) {
      lightbox.addEventListener('click', function (e) {
        if (e.target === lightbox) closeLightbox();
      });
    }

    window.addEventListener('keydown', function (e) {
      if (lightbox && lightbox.style.display === 'grid') {
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') openLightbox(currentIndex - 1);
        if (e.key === 'ArrowRight') openLightbox(currentIndex + 1);
      }
    });

    // 4. Contact Form Feedback Toast
    var contactForm = document.getElementById('contactForm');
    var toastContainer = document.getElementById('toastContainer');

    function showToast(title, message) {
      if (!toastContainer) return;
      var toast = document.createElement('div');
      toast.className = 'toast';
      toast.innerHTML = '<span class="toast-icon">✓</span><div class="toast-content"><h4>' + title + '</h4><p>' + message + '</p></div>';
      toastContainer.appendChild(toast);
      setTimeout(function () {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(function () { toast.remove(); }, 300);
      }, 5000);
    }

    if (contactForm) {
      contactForm.addEventListener('submit', function (e) {
        // If native form handler (not handled by WP plugin), prepare email
        if (!contactForm.getAttribute('action')) {
          e.preventDefault();
          var formData = new FormData(contactForm);
          var submission = {
            name: formData.get('name'),
            email: formData.get('email'),
            company: formData.get('company') || 'N/A',
            service: formData.get('service') || 'General',
            message: formData.get('message'),
            timestamp: new Date().toISOString()
          };

          try {
            var list = JSON.parse(localStorage.getItem('pixelsprings_submissions') || '[]');
            list.push(submission);
            localStorage.setItem('pixelsprings_submissions', JSON.stringify(list));
          } catch (err) {}

          showToast('Inquiry Prepared & Saved!', 'Opening your mail client for direct transmission...');

          var subject = encodeURIComponent('A question for Pixelsprings from ' + submission.name);
          var body = encodeURIComponent(
            'Name: ' + submission.name + '\n' +
            'Email: ' + submission.email + '\n' +
            'Company: ' + submission.company + '\n' +
            'Service: ' + submission.service + '\n\n' +
            'Message:\n' + submission.message
          );

          setTimeout(function () {
            window.location.href = 'mailto:contact@pixelsprings.com?subject=' + subject + '&body=' + body;
          }, 600);
        }
      });
    }
  });
})();
