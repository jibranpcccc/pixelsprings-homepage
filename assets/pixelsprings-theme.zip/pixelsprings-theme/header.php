<?php
/**
 * The header for our theme
 *
 * @package Pixelsprings
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <link rel="icon" type="image/svg+xml" href="<?php echo esc_url(get_template_directory_uri() . '/assets/images/favicon.svg'); ?>">
  <link rel="preconnect" href="https://api.fontshare.com">
  <link rel="preconnect" href="https://cdn.fontshare.com" crossorigin>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="top">
  <!-- Top Cohort Announcement Banner -->
  <div class="top-announcement-bar" role="region" aria-label="<?php esc_attr_e('Cohort Availability', 'pixelsprings'); ?>">
    <div class="announcement-inner">
      <span class="announcement-badge"><?php esc_html_e('LIMITED COHORT', 'pixelsprings'); ?></span>
      <span class="announcement-text"><?php esc_html_e('Pixelsprings is currently accepting new clients, but spaces for each cohort are limited. Claim your spot for priority onboarding.', 'pixelsprings'); ?></span>
      <a class="announcement-cta" href="mailto:contact@pixelsprings.com?subject=Priority%20Cohort%20Onboarding"><?php esc_html_e('Book a Call ↗', 'pixelsprings'); ?></a>
    </div>
  </div>

  <a class="skip-link" href="#main"><?php esc_html_e('Skip to content', 'pixelsprings'); ?></a>

  <header class="site-header">
    <div class="header-inner">
      <a class="wordmark" href="<?php echo esc_url(home_url('/')); ?>#top" aria-label="<?php esc_attr_e('Pixelsprings — back to top', 'pixelsprings'); ?>">
        <span class="brand-mark" aria-hidden="true"></span>PIXELSPRINGS
      </a>
      <nav class="nav-links" aria-label="<?php esc_attr_e('Main navigation', 'pixelsprings'); ?>">
        <a href="#services"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
        <a href="#pricing"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
        <a href="#work"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
        <a href="#agencies"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
        <a href="#faq"><?php esc_html_e('FAQ', 'pixelsprings'); ?></a>
      </nav>
      <a class="nav-cta" href="mailto:contact@pixelsprings.com?subject=Book%20a%20call"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <button class="mobile-toggle" id="mobileMenuToggle" type="button" aria-label="<?php esc_attr_e('Open navigation menu', 'pixelsprings'); ?>" aria-expanded="false" aria-controls="mobile-navigation">☰</button>
    </div>
    <nav id="mobile-navigation" class="mobile-panel" aria-label="<?php esc_attr_e('Mobile navigation', 'pixelsprings'); ?>" style="display: none;">
      <a href="#services"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
      <a href="#pricing"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
      <a href="#work"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
      <a href="#agencies"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
      <a href="#faq"><?php esc_html_e('FAQ', 'pixelsprings'); ?></a>
      <a class="button button-dark" href="mailto:contact@pixelsprings.com?subject=Book%20a%20call"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
    </nav>
  </header>
