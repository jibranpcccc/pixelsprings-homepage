<?php
/**
 * The template for displaying the Pixelsprings Homepage
 *
 * @package Pixelsprings
 */

get_header(); ?>

<main id="main">
  <?php
  // Modular homepage parts
  get_template_part('template-parts/hero');
  get_template_part('template-parts/room-to-grow');
  get_template_part('template-parts/how-it-works');
  get_template_part('template-parts/capabilities');
  get_template_part('template-parts/agency-loop');
  get_template_part('template-parts/portfolio');
  get_template_part('template-parts/founder-note');
  get_template_part('template-parts/pricing-table');
  get_template_part('template-parts/faq-accordion');
  get_template_part('template-parts/contact-section');
  ?>
</main>

<?php get_footer(); ?>
