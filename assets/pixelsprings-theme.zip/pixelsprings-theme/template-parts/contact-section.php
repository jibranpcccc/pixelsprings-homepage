<?php
/**
 * Template part: Contact & Final CTA
 *
 * @package Pixelsprings
 */
?>
<section class="section contact" id="contact" aria-labelledby="contact-title">
  <div class="wrap contact-grid">
    <div class="contact-title">
      <div class="eyebrow"><?php esc_html_e('Contact', 'pixelsprings'); ?></div>
      <h2 id="contact-title"><?php esc_html_e('Have a question?', 'pixelsprings'); ?></h2>
      <p><?php esc_html_e('Share a little about the work you have in mind.', 'pixelsprings'); ?></p>
      <a class="button button-dark consultation-button" href="mailto:contact@pixelsprings.com?subject=Book%20a%20call"><?php _e('Book a Free Consultation <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></a>
      <a class="contact-email" href="mailto:contact@pixelsprings.com">contact@pixelsprings.com</a>
    </div>
    <form id="contactForm" class="contact-form">
      <div class="field">
        <label for="contact-name"><?php esc_html_e('Name *', 'pixelsprings'); ?></label>
        <input id="contact-name" name="name" autocomplete="name" required placeholder="<?php esc_attr_e('Your full name', 'pixelsprings'); ?>">
      </div>
      <div class="field">
        <label for="contact-email"><?php esc_html_e('Email *', 'pixelsprings'); ?></label>
        <input id="contact-email" name="email" autocomplete="email" required type="email" placeholder="<?php esc_attr_e('you@company.com', 'pixelsprings'); ?>">
      </div>
      <div class="field full">
        <label for="contact-company"><?php esc_html_e('Company / Website (optional)', 'pixelsprings'); ?></label>
        <input id="contact-company" name="company" autocomplete="organization" placeholder="company.com">
      </div>
      <div class="field full">
        <label for="contact-service"><?php esc_html_e('What can we help with?', 'pixelsprings'); ?></label>
        <select id="contact-service" name="service">
          <option value=""><?php esc_html_e('Choose an area (optional)', 'pixelsprings'); ?></option>
          <option value="Design">Design &amp; Visual Identity</option>
          <option value="UI/UX">UI/UX &amp; Figma</option>
          <option value="Website">Website &amp; Landing Pages</option>
          <option value="Development">WordPress &amp; Custom Development</option>
          <option value="Ecommerce">WooCommerce / E-commerce</option>
          <option value="Agency Support">Ongoing Agency Capacity</option>
          <option value="Something Else">Something else</option>
        </select>
      </div>
      <div class="field full">
        <label for="contact-message"><?php esc_html_e('Message *', 'pixelsprings'); ?></label>
        <textarea id="contact-message" name="message" required placeholder="<?php esc_attr_e('Tell us about your upcoming creative or development projects...', 'pixelsprings'); ?>"></textarea>
      </div>
      <div class="form-bottom">
        <p class="form-note"><?php esc_html_e('Your inquiry is instantly saved & prepared in your email client for direct delivery.', 'pixelsprings'); ?></p>
        <button class="button button-dark" type="submit"><?php _e('Send Message <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></button>
      </div>
    </form>
  </div>
</section>

<!-- FINAL CTA -->
<section class="final-cta" aria-labelledby="final-cta-title">
  <div class="eyebrow"><?php esc_html_e('Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></div>
  <h2 id="final-cta-title"><?php _e('Let's make more <span class="cta-highlight">room to create.</span>', 'pixelsprings'); ?></h2>
  <div class="final-actions">
    <a class="button button-dark" href="mailto:contact@pixelsprings.com?subject=Book%20a%20call"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
    <a class="button button-light" href="#contact"><?php esc_html_e('Send a Message', 'pixelsprings'); ?></a>
  </div>
</section>
