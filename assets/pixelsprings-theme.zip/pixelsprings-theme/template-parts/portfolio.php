<?php
/**
 * Template part: Portfolio Section
 * Supports dynamic WP_Query with fallback to static assets
 *
 * @package Pixelsprings
 */
$theme_uri = get_template_directory_uri();
$default_works = array(
    array('src' => $theme_uri . '/assets/images/portfolio/work-01.jpg', 'caption' => 'Creative studio environment & hardware prototyping', 'alt' => 'Laptop and code on a bright design studio desk.'),
    array('src' => $theme_uri . '/assets/images/portfolio/work-02.jpg', 'caption' => 'Enterprise digital design system architecture', 'alt' => 'A digital design system displayed on a desktop screen.'),
    array('src' => $theme_uri . '/assets/images/portfolio/work-03.jpg', 'caption' => 'Interface design sketchbook & early wireframing', 'alt' => 'Open sketchbook with early interface notes.'),
    array('src' => $theme_uri . '/assets/images/portfolio/work-04.jpg', 'caption' => 'Responsive layout across mobile, tablet, and desktop', 'alt' => 'Responsive website design viewed across laptop and phone.'),
    array('src' => $theme_uri . '/assets/images/portfolio/work-05.jpg', 'caption' => 'Collaborative team sprint review & product delivery', 'alt' => 'A team reviewing a digital project together.'),
    array('src' => $theme_uri . '/assets/images/portfolio/work-06.jpg', 'caption' => 'Creative strategy & agency leadership round-table', 'alt' => 'A creative team meeting around a conference table.')
);

$cpt_query = new WP_Query(array('post_type' => 'portfolio_work', 'posts_per_page' => 6));
$works_to_render = array();

if ($cpt_query->have_posts()) {
    while ($cpt_query->have_posts()) {
        $cpt_query->the_post();
        $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
        if ($thumb_url) {
            $works_to_render[] = array(
                'src'     => $thumb_url,
                'caption' => get_the_excerpt() ?: get_the_title(),
                'alt'     => get_the_title(),
            );
        }
    }
    wp_reset_postdata();
}

if (empty($works_to_render)) {
    $works_to_render = $default_works;
}
?>
<section class="section work" id="work" aria-labelledby="work-title">
  <div class="wrap">
    <div class="work-header">
      <div>
        <div class="eyebrow"><?php esc_html_e('Portfolio', 'pixelsprings'); ?></div>
        <h2 id="work-title"><?php esc_html_e('Creative possibilities.', 'pixelsprings'); ?></h2>
      </div>
      <p><?php esc_html_e('Curated visual studies showcasing our multidisciplinary design standards.', 'pixelsprings'); ?></p>
    </div>
    <div class="gallery" data-testid="gallery-projects">
      <?php foreach ($works_to_render as $idx => $work): ?>
      <button class="project" type="button" aria-label="<?php echo esc_attr($work['caption']); ?>" data-index="<?php echo $idx; ?>" data-caption="<?php echo esc_attr($work['caption']); ?>">
        <div class="project-art">
          <img alt="<?php echo esc_attr($work['alt']); ?>" loading="lazy" src="<?php echo esc_url($work['src']); ?>">
        </div>
      </button>
      <?php endforeach; ?>
    </div>
  </div>
</section>
