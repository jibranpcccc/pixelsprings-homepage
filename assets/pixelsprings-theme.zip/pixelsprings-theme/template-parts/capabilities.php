<?php
/**
 * Template part: Capabilities
 *
 * @package Pixelsprings
 */
?>
<section class="section capabilities" id="capabilities" aria-labelledby="capabilities-title">
  <div class="wrap">
    <div class="cap-intro">
      <div>
        <div class="eyebrow"><?php esc_html_e('Our capabilities', 'pixelsprings'); ?></div>
        <h2 id="capabilities-title"><?php _e('A broad production<br>practice.', 'pixelsprings'); ?></h2>
      </div>
      <p><?php esc_html_e('One thoughtful team across the work that makes a brand visible, useful, and ready to grow.', 'pixelsprings'); ?></p>
    </div>
    <div class="cap-list">
      <article class="capability">
        <div class="cap-label"><?php esc_html_e('Discipline 01', 'pixelsprings'); ?></div>
        <h3><?php esc_html_e('Design', 'pixelsprings'); ?></h3>
        <ul>
          <li>Graphic design</li>
          <li>Logo design</li>
          <li>Branding</li>
          <li>Packaging</li>
          <li>Print materials</li>
          <li>Social media creatives</li>
          <li>Advertising creatives</li>
          <li>Marketing collateral</li>
          <li>Presentation design</li>
        </ul>
      </article>
      <article class="capability">
        <div class="cap-label"><?php esc_html_e('Discipline 02', 'pixelsprings'); ?></div>
        <h3><?php esc_html_e('Digital', 'pixelsprings'); ?></h3>
        <ul>
          <li>UI/UX</li>
          <li>Figma</li>
          <li>Website design</li>
          <li>Landing pages</li>
          <li>WordPress</li>
          <li>Webflow</li>
          <li>Website redesigns</li>
          <li>Website updates</li>
          <li>Responsive implementation</li>
        </ul>
      </article>
      <article class="capability">
        <div class="cap-label"><?php esc_html_e('Discipline 03', 'pixelsprings'); ?></div>
        <h3><?php esc_html_e('Development', 'pixelsprings'); ?></h3>
        <ul>
          <li>Custom coding</li>
          <li>Advanced WordPress</li>
          <li>WooCommerce</li>
          <li>E-commerce</li>
          <li>Custom functionality</li>
          <li>API / integrations</li>
          <li>Third-party integrations</li>
          <li>Front-end / back-end development</li>
        </ul>
      </article>
    </div>
  </div>
</section>
