<?php
/**
 * Template part: For Agencies & Seamless Loop
 *
 * @package Pixelsprings
 */
?>
<section class="section agency" id="agencies" aria-labelledby="agency-title">
  <div class="wrap agency-grid">
    <div>
      <div class="eyebrow"><?php esc_html_e('Your behind-the-scenes advantage', 'pixelsprings'); ?></div>
      <h2 id="agency-title"><?php _e('Your clients.<br><em>Your brand.</em><br>Our production team.', 'pixelsprings'); ?></h2>
      <p class="agency-lede"><?php esc_html_e('A production partner that fits quietly into your agency — so you can say yes to good work and keep the relationship where it belongs: with you.', 'pixelsprings'); ?></p>
    </div>
    <div class="agency-list">
      <div class="partnership-loop" aria-label="<?php esc_attr_e('The seamless partnership loop', 'pixelsprings'); ?>">
        <div class="loop-kicker"><?php esc_html_e('THE SEAMLESS PARTNERSHIP LOOP', 'pixelsprings'); ?></div>
        <div class="loop-flow">
          <div><b>YOUR AGENCY</b><span>Strategy &amp; relationships</span></div>
          <i aria-hidden="true">→</i>
          <div><b>PIXELSPRINGS</b><span>Creative &amp; technical production</span></div>
          <i aria-hidden="true">→</i>
          <div><b>CLIENT OUTPUT</b><span>Delivered under your brand</span></div>
        </div>
      </div>
      <article class="agency-item">
        <h3><?php esc_html_e('White-label friendly', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('We work behind the scenes so your client relationship stays yours.', 'pixelsprings'); ?></p>
      </article>
      <article class="agency-item">
        <h3><?php esc_html_e('No direct client communication', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('We do not communicate directly with your clients unless you specifically authorize it.', 'pixelsprings'); ?></p>
      </article>
      <article class="agency-item">
        <h3><?php esc_html_e('No Pixelsprings branding', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('Deliverables remain under your brand unless otherwise agreed.', 'pixelsprings'); ?></p>
      </article>
      <article class="agency-item">
        <h3><?php esc_html_e('NDA-friendly', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('We understand confidential agency relationships and client work.', 'pixelsprings'); ?></p>
      </article>
      <article class="agency-item">
        <h3><?php esc_html_e('Client relationship stays yours', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('You remain the client-facing team.', 'pixelsprings'); ?></p>
      </article>
      <article class="agency-item">
        <h3><?php esc_html_e('Design + web + development', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('One production partner across multiple disciplines.', 'pixelsprings'); ?></p>
      </article>
    </div>
  </div>
</section>
