<?php
/**
 * Template part: Founder Note
 *
 * @package Pixelsprings
 */
?>
<section class="section founder-note" aria-labelledby="founder-title">
  <div class="wrap">
    <div class="founder-card">
      <div class="eyebrow"><?php esc_html_e('A Note from the Founders', 'pixelsprings'); ?></div>
      <blockquote id="founder-title">
        “<?php esc_html_e('We built Pixelsprings to give growing teams access to great creative work without the overhead of building another full-time team.', 'pixelsprings'); ?>”
      </blockquote>
      <div class="founder-byline">
        <strong>— <?php esc_html_e('Noman & Umair', 'pixelsprings'); ?></strong>
        <span><?php esc_html_e('Founders, Pixelsprings', 'pixelsprings'); ?></span>
      </div>
    </div>
  </div>
</section>
