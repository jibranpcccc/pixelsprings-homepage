<?php
/**
 * Template part: Hero Section
 *
 * @package Pixelsprings
 */
$theme_uri = get_template_directory_uri();
?>
<section class="hero" aria-labelledby="hero-title">
  <div class="hero-inner">
    <div class="eyebrow"><?php esc_html_e('Design + development, on subscription', 'pixelsprings'); ?></div>
    <h1 id="hero-title"><?php _e('Your creative team,<br><span>without the hiring headache.</span>', 'pixelsprings'); ?></h1>
    <p class="hero-copy"><?php esc_html_e('Design, web and development support for agencies and growing businesses — available through one simple monthly subscription.', 'pixelsprings'); ?></p>
    <div class="hero-actions">
      <a class="button button-dark" href="#pricing"><?php _e('View Plans <span aria-hidden="true">&nbsp;↗</span>', 'pixelsprings'); ?></a>
      <a class="button button-light" href="mailto:contact@pixelsprings.com?subject=Book%20a%20call"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
    </div>
    <p class="hero-note"><?php _e('Unlimited requests <span aria-hidden="true">·</span> 1–3 active at a time <span aria-hidden="true">·</span> Cancel anytime', 'pixelsprings'); ?></p>

    <div class="hero-board" role="img" aria-label="<?php esc_attr_e('Moving strip of Pixelsprings design and development work', 'pixelsprings'); ?>">
      <div class="hero-marquee" aria-hidden="true">
        <div class="hero-track">
          <?php for ($loop = 0; $loop < 2; $loop++): ?>
          <div class="hero-track-group">
            <div class="hero-tile hero-tile-1"><img alt="" src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-01.jpg'); ?>"></div>
            <div class="hero-tile hero-tile-2"><img alt="" src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-02.jpg'); ?>"></div>
            <div class="hero-tile hero-tile-3"><img alt="" src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-03.jpg'); ?>"></div>
            <div class="hero-tile hero-tile-4"><img alt="" src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-04.jpg'); ?>"></div>
            <div class="hero-tile hero-tile-5"><img alt="" src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-05.jpg'); ?>"></div>
            <div class="hero-tile hero-tile-6"><img alt="" src="<?php echo esc_url($theme_uri . '/assets/images/portfolio/work-06.jpg'); ?>"></div>
          </div>
          <?php endfor; ?>
        </div>
      </div>
    </div>
    <div class="hero-rule" aria-hidden="true"></div>
  </div>
</section>
