<?php
/**
 * Template part: How It Works
 *
 * @package Pixelsprings
 */
?>
<section class="section" aria-labelledby="rhythm-title">
  <div class="wrap rhythm">
    <div class="section-top">
      <div class="eyebrow"><?php esc_html_e('How it works', 'pixelsprings'); ?></div>
      <h2 id="rhythm-title"><?php _e('GREAT CREATIVE<br>WORK, WITHOUT THE<br>COMPLICATED PROCESS', 'pixelsprings'); ?></h2>
    </div>
    <div class="timeline" data-testid="production-timeline">
      <article class="step">
        <div class="step-num">01</div>
        <div>
          <h3><?php esc_html_e('CHOOSE YOUR PLAN', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Choose the production capacity that fits your team.', 'pixelsprings'); ?></p>
        </div>
      </article>
      <article class="step">
        <div class="step-num">02</div>
        <div>
          <h3><?php esc_html_e('SHARE YOUR VISION', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Send requests whenever work comes up. We handle the production.', 'pixelsprings'); ?></p>
        </div>
      </article>
      <article class="step">
        <div class="step-num">03</div>
        <div>
          <h3><?php esc_html_e('REVIEW, REFINE & DELIVER', 'pixelsprings'); ?></h3>
          <p><?php esc_html_e('Review the work, request revisions, approve, and move to the next request.', 'pixelsprings'); ?></p>
        </div>
      </article>
    </div>
  </div>
</section>
