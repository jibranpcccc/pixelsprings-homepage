<?php
/**
 * Template part: Pricing Comparison Matrix
 *
 * @package Pixelsprings
 */
?>
<section class="section pricing" id="pricing" aria-labelledby="pricing-title">
  <div class="wrap">
    <div class="pricing-heading">
      <div class="eyebrow"><?php esc_html_e('Pricing', 'pixelsprings'); ?></div>
      <h2 id="pricing-title"><?php esc_html_e('Choose the production capacity that fits your team.', 'pixelsprings'); ?></h2>
    </div>
    <div class="pricing-scroll" role="region" aria-label="<?php esc_attr_e('Pricing comparison; scroll horizontally to compare all plans', 'pixelsprings'); ?>" tabindex="0">
      <div class="price-table">
        <div class="price-head">
          <div class="price-plan"><span class="eyebrow"><?php esc_html_e('Monthly subscription', 'pixelsprings'); ?></span></div>
          <div class="price-plan">
            <h3>PIXEL SPARK</h3>
            <div class="price">$799<small>/month</small></div>
            <p><?php esc_html_e('1 active request', 'pixelsprings'); ?></p>
            <a class="button button-light" href="mailto:contact@pixelsprings.com?subject=Pixel%20Spark%20plan"><?php esc_html_e('Choose Spark', 'pixelsprings'); ?></a>
          </div>
          <div class="price-plan featured">
            <h3>PIXEL FLOW</h3>
            <div class="price">$1,499<small>/month</small></div>
            <p><?php esc_html_e('2 active requests', 'pixelsprings'); ?></p>
            <a class="button button-dark" href="mailto:contact@pixelsprings.com?subject=Pixel%20Flow%20plan"><?php esc_html_e('Choose Flow', 'pixelsprings'); ?></a>
          </div>
          <div class="price-plan">
            <h3>PIXEL FORGE</h3>
            <div class="price">$2,499<small>/month</small></div>
            <p><?php esc_html_e('3 active requests', 'pixelsprings'); ?></p>
            <a class="button button-light" href="mailto:contact@pixelsprings.com?subject=Pixel%20Forge%20plan"><?php esc_html_e('Choose Forge', 'pixelsprings'); ?></a>
          </div>
        </div>

        <!-- DESIGN -->
        <div>
          <div class="price-row category"><span><?php esc_html_e('DESIGN', 'pixelsprings'); ?></span><span></span><span></span><span></span></div>
          <div class="price-row"><span>Graphic design</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Logo design</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Branding</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Packaging</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Print materials</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Social media creatives</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Advertising creatives</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Marketing collateral</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Presentation design</span><span class="yes">✓</span><span class="yes">✓</span><span class="yes">✓</span></div>
        </div>

        <!-- DIGITAL -->
        <div>
          <div class="price-row category"><span><?php esc_html_e('DIGITAL', 'pixelsprings'); ?></span><span></span><span></span><span></span></div>
          <div class="price-row"><span>UI/UX</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Figma</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Website design</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Landing pages</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>WordPress</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Webflow</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Website redesigns</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Website updates</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Responsive implementation</span><span class="not-yet">—</span><span class="yes">✓</span><span class="yes">✓</span></div>
        </div>

        <!-- DEVELOPMENT -->
        <div>
          <div class="price-row category"><span><?php esc_html_e('DEVELOPMENT', 'pixelsprings'); ?></span><span></span><span></span><span></span></div>
          <div class="price-row"><span>Custom coding</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Advanced WordPress</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
          <div class="price-row"><span>WooCommerce</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
          <div class="price-row"><span>E-commerce</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Custom functionality</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
          <div class="price-row"><span>API / integrations</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Third-party integrations</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
          <div class="price-row"><span>Front-end / back-end development</span><span class="not-yet">—</span><span class="not-yet">—</span><span class="yes">✓</span></div>
        </div>
      </div>
    </div>
    <p class="pricing-scroll-hint"><?php esc_html_e('Swipe to compare all three plans →', 'pixelsprings'); ?></p>
    <p class="pricing-note"><strong><?php esc_html_e('One note on scope:', 'pixelsprings'); ?></strong> <?php esc_html_e('Large or complex projects are handled through milestones within your active production capacity.', 'pixelsprings'); ?></p>
  </div>
</section>
