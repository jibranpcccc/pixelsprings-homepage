<?php
/**
 * Template part: FAQ Accordion
 *
 * @package Pixelsprings
 */
$faqs = array(
    array('What does unlimited requests mean?', 'You can keep adding work to your request queue and prioritize what matters most. Your plan sets how many requests can be active at once.'),
    array('How many requests can be active?', 'Pixel Spark includes one active request, Pixel Flow includes two, and Pixel Forge includes three.'),
    array('What counts as a request?', 'A request is a clearly defined deliverable, such as a design asset, a web page, or a scoped development task. Larger or connected work can be organized into milestones.'),
    array('How do large websites work?', 'Large or complex projects are handled through milestones within your active production capacity.'),
    array('How do revisions work?', 'Review the work, share your feedback, and request revisions within the original scope.'),
    array('Can I pause or cancel?', 'You can cancel anytime. If you are looking to pause rather than cancel, contact us and we can clarify the available options.'),
    array('Do you work with agencies?', 'Yes. Pixelsprings is set up to support agency teams with flexible design, digital, and development production.'),
    array('Can you work white-label?', 'Yes. We work behind the scenes so your client relationship stays yours. Deliverables remain under your brand unless otherwise agreed.'),
    array('Do you communicate directly with my clients?', 'Only when you specifically authorize it. Otherwise, we work with your team behind the scenes.'),
    array('What if I need development?', 'Development is included with Pixel Forge. Pixel Spark and Pixel Flow focus on design and digital services.'),
    array('What tools do you use?', 'The right tools depend on your workflow and project. Tell us what your team already uses and we can confirm the fit before work begins.')
);
?>
<section class="section" id="faq" aria-labelledby="faq-title">
  <div class="wrap faq">
    <div class="faq-title">
      <div class="eyebrow"><?php esc_html_e('A few good questions', 'pixelsprings'); ?></div>
      <h2 id="faq-title"><?php esc_html_e('Good to know.', 'pixelsprings'); ?></h2>
      <p><?php esc_html_e('A little more on how the work works.', 'pixelsprings'); ?></p>
    </div>
    <div class="faq-list">
      <?php foreach ($faqs as $index => $item): ?>
      <div class="faq-item">
        <h3 style="margin: 0px;">
          <button class="faq-question" id="faq-trigger-<?php echo $index; ?>" type="button" aria-expanded="false" aria-controls="faq-answer-<?php echo $index; ?>">
            <span><?php echo esc_html($item[0]); ?></span><span class="faq-icon" aria-hidden="true">+</span>
          </button>
        </h3>
        <div class="faq-answer" id="faq-answer-<?php echo $index; ?>" role="region" aria-labelledby="faq-trigger-<?php echo $index; ?>" aria-hidden="true">
          <div><p><?php echo esc_html($item[1]); ?></p></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
