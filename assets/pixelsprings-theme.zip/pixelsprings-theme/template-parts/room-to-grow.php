<?php
/**
 * Template part: Room to Grow
 *
 * @package Pixelsprings
 */
?>
<section class="section growth" id="services" aria-labelledby="growth-title">
  <div class="wrap">
    <div class="section-top">
      <div>
        <div class="eyebrow"><?php esc_html_e('Room to grow', 'pixelsprings'); ?></div>
        <h2 id="growth-title"><?php _e('More work shouldn't<br>mean more hiring.', 'pixelsprings'); ?></h2>
      </div>
      <p class="section-intro"><?php esc_html_e('Good work comes in waves. Add steady production support when the work is there — without changing the shape of your team.', 'pixelsprings'); ?></p>
    </div>
    <div class="growth-points">
      <article class="growth-point">
        <span class="index"><?php esc_html_e('01 / CAPACITY', 'pixelsprings'); ?></span>
        <h3><?php esc_html_e('More capacity', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('Add production capacity without adding another full-time hire.', 'pixelsprings'); ?></p>
      </article>
      <article class="growth-point">
        <span class="index"><?php esc_html_e('02 / RANGE', 'pixelsprings'); ?></span>
        <h3><?php esc_html_e('One flexible team', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('Design, web, and development support in one subscription.', 'pixelsprings'); ?></p>
      </article>
      <article class="growth-point">
        <span class="index"><?php esc_html_e('03 / RHYTHM', 'pixelsprings'); ?></span>
        <h3><?php esc_html_e('Predictable production', 'pixelsprings'); ?></h3>
        <p><?php esc_html_e('A simple monthly model built for ongoing work.', 'pixelsprings'); ?></p>
      </article>
    </div>
  </div>
</section>
