<?php
/**
 * Pixelsprings Theme Functions and Definitions
 *
 * @package Pixelsprings
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('PIXELSPRINGS_VERSION', '1.0.0');

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function pixelsprings_setup() {
    // Make theme available for translation.
    load_theme_textdomain('pixelsprings', get_template_directory() . '/languages');

    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title.
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(1200, 800, true);

    // Register navigation menus
    register_nav_menus(array(
        'primary' => esc_html__('Primary Header Navigation', 'pixelsprings'),
        'footer'  => esc_html__('Footer Navigation', 'pixelsprings'),
    ));

    // Switch default core markup for search form, comment form, and comments to output valid HTML5.
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
}
add_action('after_setup_theme', 'pixelsprings_setup');

/**
 * Enqueue scripts and styles.
 */
function pixelsprings_scripts() {
    // Web Fonts (Satoshi from Fontshare and Plus Jakarta Sans from Google Fonts)
    wp_enqueue_style('fontshare-satoshi', 'https://api.fontshare.com/v2/css?f[]=satoshi@400,500,600,700&display=swap', array(), null);
    wp_enqueue_style('google-jakarta', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap', array(), null);

    // Main Compiled & Normalized CSS
    wp_enqueue_style('pixelsprings-main', get_template_directory_uri() . '/assets/css/main.css', array(), PIXELSPRINGS_VERSION);
    wp_enqueue_style('pixelsprings-custom', get_template_directory_uri() . '/assets/css/custom.css', array('pixelsprings-main'), PIXELSPRINGS_VERSION);

    // Theme Core JavaScript
    wp_enqueue_script('pixelsprings-script', get_template_directory_uri() . '/assets/js/pixelsprings.js', array(), PIXELSPRINGS_VERSION, true);
}
add_action('wp_enqueue_scripts', 'pixelsprings_scripts');

/**
 * Register Custom Post Type for Portfolio Works
 */
function pixelsprings_register_cpt() {
    $labels = array(
        'name'                  => _x('Portfolio Works', 'Post type general name', 'pixelsprings'),
        'singular_name'         => _x('Portfolio Work', 'Post type singular name', 'pixelsprings'),
        'menu_name'             => _x('Portfolio', 'Admin Menu text', 'pixelsprings'),
        'name_admin_bar'        => _x('Portfolio Work', 'Add New on Toolbar', 'pixelsprings'),
        'add_new'               => __('Add New', 'pixelsprings'),
        'add_new_item'          => __('Add New Portfolio Work', 'pixelsprings'),
        'new_item'              => __('New Work', 'pixelsprings'),
        'edit_item'             => __('Edit Work', 'pixelsprings'),
        'view_item'             => __('View Work', 'pixelsprings'),
        'all_items'             => __('All Works', 'pixelsprings'),
        'search_items'          => __('Search Works', 'pixelsprings'),
        'not_found'             => __('No works found.', 'pixelsprings'),
        'not_found_in_trash'    => __('No works found in Trash.', 'pixelsprings'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'work'),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-format-gallery',
        'supports'           => array('title', 'thumbnail', 'excerpt'),
        'show_in_rest'       => true,
    );

    register_post_type('portfolio_work', $args);
}
add_action('init', 'pixelsprings_register_cpt');
