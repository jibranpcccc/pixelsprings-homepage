<?php
/**
 * The template for displaying the footer
 *
 * @package Pixelsprings
 */
?>
    <!-- FOOTER -->
    <footer class="site-footer">
      <div class="wrap">
        <div class="footer-main">
          <div class="footer-brand">
            <a class="wordmark" href="#top" aria-label="<?php esc_attr_e('Pixelsprings — back to top', 'pixelsprings'); ?>">
              <span class="brand-mark" aria-hidden="true"></span>PIXELSPRINGS
            </a>
            <p><?php _e('Design and development,<br>on subscription.<br>Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></p>
            <a class="footer-email" href="mailto:contact@pixelsprings.com">contact@pixelsprings.com</a>
          </div>
          <div>
            <div class="footer-label"><?php esc_html_e('Explore', 'pixelsprings'); ?></div>
            <nav class="footer-nav" aria-label="<?php esc_attr_e('Footer navigation', 'pixelsprings'); ?>">
              <a href="#services"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
              <a href="#pricing"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
              <a href="#work"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
              <a href="#agencies"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
              <a href="mailto:contact@pixelsprings.com?subject=Book%20a%20call"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
            </nav>
          </div>
          <div>
            <div class="footer-label"><?php esc_html_e('Elsewhere', 'pixelsprings'); ?></div>
            <div class="footer-social">
              <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-linkedin"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
              </a>
              <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="Instagram">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-instagram"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line></svg>
              </a>
              <a href="https://x.com/" target="_blank" rel="noreferrer" aria-label="X">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 2H22l-6.8 7.8L23.2 22h-6.3L12 14.6 5.6 22H2.4l7.3-8.4L1.8 2h6.4l4.5 6.8L18.9 2Zm-1.1 18h1.7L7.3 3.9H5.5L17.8 20Z"></path></svg>
              </a>
              <a href="https://www.facebook.com/" target="_blank" rel="noreferrer" aria-label="Facebook">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-facebook"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
              </a>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <span><?php printf(esc_html__('© %s Pixelsprings. All rights reserved.', 'pixelsprings'), date('Y')); ?></span>
          <div class="footer-legal">
            <a href="mailto:contact@pixelsprings.com?subject=Privacy%20enquiry"><?php esc_html_e('Privacy', 'pixelsprings'); ?></a>
            <a href="mailto:contact@pixelsprings.com?subject=Terms%20enquiry"><?php esc_html_e('Terms', 'pixelsprings'); ?></a>
          </div>
        </div>
      </div>
    </footer>
  </div>

  <!-- Toast Feedback Container -->
  <div id="toastContainer" class="toast-container"></div>

  <!-- Lightbox Modal -->
  <div id="projectLightbox" class="project-lightbox" style="display: none;" role="presentation">
    <div class="lightbox-inner" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Portfolio image preview', 'pixelsprings'); ?>">
      <button id="lightboxClose" class="lightbox-close" type="button" aria-label="<?php esc_attr_e('Close project preview', 'pixelsprings'); ?>">×</button>
      <div class="project-art">
        <img id="lightboxImg" alt="" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E">
      </div>
      <button id="lightboxPrev" class="lightbox-nav-btn lightbox-prev" type="button" aria-label="<?php esc_attr_e('Previous image', 'pixelsprings'); ?>">‹</button>
      <button id="lightboxNext" class="lightbox-nav-btn lightbox-next" type="button" aria-label="<?php esc_attr_e('Next image', 'pixelsprings'); ?>">›</button>
      <div id="lightboxCaption" class="lightbox-caption"></div>
    </div>
  </div>

  <?php wp_footer(); ?>
</body>
</html>
