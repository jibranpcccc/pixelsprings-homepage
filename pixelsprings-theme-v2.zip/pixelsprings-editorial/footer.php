<?php
/**
 * Pixelsprings Editorial Theme Footer
 *
 * @package Pixelsprings
 */
$theme_uri = get_template_directory_uri();
?>
    <footer class="site-footer">
      <div class="wrap">
        <div class="footer-main">
          <div class="footer-brand">
            <a class="wordmark" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Pixelsprings — home', 'pixelsprings'); ?>" data-testid="link-footer-brand">
              <img class="wordmark-logo" src="<?php echo esc_url($theme_uri . '/assets/images/pixelsprings-logo.png'); ?>" alt="Pixelsprings" />
            </a>
            <p><?php _e('Design and development,<br>on subscription.', 'pixelsprings'); ?></p>
            <p class="footer-location"><?php esc_html_e('Based in Texas. Built to work worldwide.', 'pixelsprings'); ?></p>
          </div>
          <div>
            <div class="footer-label"><?php esc_html_e('Explore', 'pixelsprings'); ?></div>
            <nav class="footer-nav" aria-label="<?php esc_attr_e('Footer navigation', 'pixelsprings'); ?>">
              <a href="<?php echo esc_url(home_url('/services')); ?>" data-testid="link-footer-services"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
              <a href="<?php echo esc_url(home_url('/pricing')); ?>" data-testid="link-footer-pricing"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
              <a href="<?php echo esc_url(home_url('/work')); ?>" data-testid="link-footer-work"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
              <a href="<?php echo esc_url(home_url('/for-agencies')); ?>" data-testid="link-footer-agencies"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
              <a href="<?php echo esc_url(home_url('/contact')); ?>" data-testid="link-footer-contact"><?php esc_html_e('Contact', 'pixelsprings'); ?></a>
              <a href="<?php echo esc_url(home_url('/book-a-call')); ?>" data-testid="link-footer-book-call"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
            </nav>
          </div>
          <div>
            <div class="footer-label"><?php esc_html_e('Elsewhere', 'pixelsprings'); ?></div>
            <div class="footer-social">
              <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="<?php esc_attr_e('LinkedIn (opens in a new tab)', 'pixelsprings'); ?>" data-testid="link-social-linkedin">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
              </a>
              <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" aria-label="<?php esc_attr_e('Instagram (opens in a new tab)', 'pixelsprings'); ?>" data-testid="link-social-instagram">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line></svg>
              </a>
              <a href="https://x.com/" target="_blank" rel="noreferrer" aria-label="<?php esc_attr_e('X (opens in a new tab)', 'pixelsprings'); ?>" data-testid="link-social-x">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 2H22l-6.8 7.8L23.2 22h-6.3L12 14.6 5.6 22H2.4l7.3-8.4L1.8 2h6.4l4.5 6.8L18.9 2Zm-1.1 18h1.7L7.3 3.9H5.5L17.8 20Z"></path></svg>
              </a>
              <a href="https://www.facebook.com/" target="_blank" rel="noreferrer" aria-label="<?php esc_attr_e('Facebook (opens in a new tab)', 'pixelsprings'); ?>" data-testid="link-social-facebook">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
              </a>
            </div>
            <a class="footer-email footer-email-right" href="mailto:contact@pixelsprings.com" data-testid="link-footer-email">contact@pixelsprings.com</a>
          </div>
        </div>
        <div class="footer-bottom">
          <span><?php printf(esc_html__('© %s Pixelsprings. All rights reserved.', 'pixelsprings'), date('Y')); ?></span>
          <div class="footer-legal">
            <a href="<?php echo esc_url(home_url('/privacy')); ?>" data-testid="link-footer-privacy"><?php esc_html_e('Privacy', 'pixelsprings'); ?></a>
            <a href="<?php echo esc_url(home_url('/terms')); ?>" data-testid="link-footer-terms"><?php esc_html_e('Terms', 'pixelsprings'); ?></a>
          </div>
        </div>
      </div>
    </footer>
  </div>

  <!-- Toast Notification Container -->
  <div id="toastContainer" class="toast-container"></div>

  <!-- Accessible Lightbox Modal -->
  <div id="projectLightbox" class="project-lightbox" style="display: none;" role="presentation">
    <div class="lightbox-inner" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Portfolio image preview', 'pixelsprings'); ?>">
      <button id="lightboxClose" class="lightbox-close" type="button" aria-label="Close project preview" data-testid="button-close-lightbox">&times;</button>
      <div class="project-art">
        <img id="lightboxImg" alt="" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E">
      </div>
      <button id="lightboxPrev" class="lightbox-nav-btn lightbox-prev" type="button" aria-label="Previous image">&larr;</button>
      <button id="lightboxNext" class="lightbox-nav-btn lightbox-next" type="button" aria-label="Next image">&rarr;</button>
    </div>
  </div>

  <?php wp_footer(); ?>
  <!-- Inline Carousel Dynamic Scaling Engine -->
  <script id="pixelsprings-carousel-v3">
  (function() {
    function initCarousel() {
      var marquee = document.querySelector('.hero-marquee');
      if (!marquee) return;
      var tiles = Array.from(marquee.querySelectorAll('.hero-tile'));
      var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
      var mobileViewport = window.matchMedia('(max-width: 680px)');

      function updatePerspective() {
        if (reducedMotion.matches) return;
        var rect = marquee.getBoundingClientRect();
        var center = rect.left + rect.width / 2;
        var halfWidth = Math.max(rect.width / 2, 1);
        var rotationLimit = mobileViewport.matches ? 12 : 24;

        tiles.forEach(function (tile) {
          var bounds = tile.getBoundingClientRect();
          var position = ((bounds.left + bounds.width / 2) - center) / halfWidth;
          var dist = Math.min(Math.abs(position), 1.35);
          var rotateY = -position * rotationLimit;
          var depth = Math.pow(dist, 1.35) * (mobileViewport.matches ? 30 : 90);
          var scale = mobileViewport.matches
            ? (1.04 - Math.pow(dist, 1.1) * 0.22)
            : (1.08 - Math.pow(dist, 1.15) * 0.34);

          tile.style.transform = 'perspective(1100px) rotateY(' + rotateY.toFixed(2) + 'deg) translateZ(-' + depth.toFixed(1) + 'px) scale(' + Math.max(0.62, scale).toFixed(3) + ')';
        });
      }

      function loop() {
        updatePerspective();
        requestAnimationFrame(loop);
      }
      requestAnimationFrame(loop);
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initCarousel);
    } else {
      initCarousel();
    }
  })();
  </script>
</body>
</html>
