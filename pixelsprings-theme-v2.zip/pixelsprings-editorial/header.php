<?php
/**
 * Pixelsprings Editorial Theme Header
 *
 * @package Pixelsprings
 */
$theme_uri = get_template_directory_uri();
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
  <link rel="icon" type="image/x-icon" href="<?php echo esc_url($theme_uri . '/assets/images/favicon.ico'); ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url($theme_uri . '/assets/images/favicon-32x32.png'); ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo esc_url($theme_uri . '/assets/images/favicon-16x16.png'); ?>">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url($theme_uri . '/assets/images/apple-touch-icon.png'); ?>">
  <link rel="icon" type="image/svg+xml" href="<?php echo esc_url($theme_uri . '/assets/images/favicon.svg'); ?>">
  <link rel="preconnect" href="https://api.fontshare.com">
  <link rel="preconnect" href="https://cdn.fontshare.com" crossorigin>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <?php wp_head(); ?>
  <!-- Inline Critical Styles for Instant 100% Rendering -->
  <style id="pixelsprings-critical-v3">
    /* 1. Hero 3D Carousel Continuous Sliding */
    @keyframes marquee-scroll {
      0% { transform: translate3d(0, 0, 0); }
      100% { transform: translate3d(-50%, 0, 0); }
    }
    .hero-marquee {
      display: flex !important;
      align-items: center !important;
      width: 100% !important;
      min-height: 380px !important;
      padding: 24px 0 !important;
      overflow: hidden !important;
      mask-image: linear-gradient(90deg, transparent 0%, #000 6%, #000 94%, transparent 100%) !important;
      -webkit-mask-image: linear-gradient(90deg, transparent 0%, #000 6%, #000 94%, transparent 100%) !important;
    }
    .hero-track {
      display: flex !important;
      gap: 24px !important;
      will-change: transform !important;
      animation: marquee-scroll 28s linear infinite !important;
      transform-style: preserve-3d !important;
    }
    .hero-marquee:hover .hero-track {
      animation-play-state: paused !important;
    }
    .hero-track-group {
      display: flex !important;
      gap: 24px !important;
      transform-style: preserve-3d !important;
    }
    .hero-tile {
      flex: 0 0 250px !important;
      width: 250px !important;
      height: 330px !important;
      border-radius: 16px !important;
      overflow: hidden !important;
      position: relative !important;
      background: #151515 !important;
      box-shadow: 0 18px 38px rgba(17, 17, 17, 0.16) !important;
      transform-origin: 50% 50% !important;
      will-change: transform !important;
      isolation: isolate !important;
      border: 1px solid rgba(255, 255, 255, 0.1) !important;
      transition: none !important;
    }

    /* 2. Timeline Note Collision Fix */
    .timeline-note {
      margin-top: 28px !important;
      font-size: 15px !important;
      line-height: 1.6 !important;
      color: var(--muted, #888888) !important;
      font-style: normal !important;
      clear: both !important;
    }

    /* 3. The Seamless Partnership Loop: Zero Divider Line */
    .agency-list {
      border-top: none !important;
    }

    /* 4. Portfolio 9-Item Grid: 4 Columns, 3 Rows */
    .gallery {
      display: grid !important;
      grid-template-columns: repeat(4, 1fr) !important;
      gap: 20px !important;
      margin-top: 36px !important;
    }
    .gallery .project {
      border-radius: 14px !important;
      overflow: hidden !important;
      background: #ebeae4 !important;
      border: 1px solid rgba(0, 0, 0, 0.06) !important;
      padding: 0 !important;
      margin: 0 !important;
      cursor: pointer !important;
      position: relative !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
      transition: transform 0.25s ease, box-shadow 0.25s ease !important;
    }
    .gallery .project:hover {
      transform: translateY(-4px) !important;
      box-shadow: 0 16px 32px rgba(0, 0, 0, 0.1) !important;
    }
    .gallery .project-art {
      width: 100% !important;
      height: 100% !important;
      position: relative !important;
      overflow: hidden !important;
    }
    .gallery .project-art img {
      width: 100% !important;
      height: 100% !important;
      object-fit: cover !important;
      display: block !important;
      transition: transform 0.35s ease !important;
    }
    .gallery .project:hover .project-art img {
      transform: scale(1.04) !important;
    }
    /* Row 1: Item 1 Rect (span 2), Item 2 Sq (span 1), Item 3 Sq (span 1) */
    /* Row 2: Item 4 Sq (span 1), Item 5 Rect (span 2), Item 6 Sq (span 1) */
    /* Row 3: Item 7 Sq (span 1), Item 8 Sq (span 1), Item 9 Rect (span 2) */
    .gallery .project.project-rect {
      grid-column: span 2 !important;
    }
    .gallery .project.project-rect .project-art {
      aspect-ratio: 2 / 1 !important;
    }
    .gallery .project.project-sq {
      grid-column: span 1 !important;
    }
    .gallery .project.project-sq .project-art {
      aspect-ratio: 1 / 1 !important;
    }
    @media (max-width: 900px) {
      .gallery {
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 16px !important;
      }
      .gallery .project.project-rect,
      .gallery .project.project-sq {
        grid-column: span 1 !important;
      }
      .gallery .project.project-rect .project-art,
      .gallery .project.project-sq .project-art {
        aspect-ratio: 4 / 3 !important;
      }
    }
    @media (max-width: 600px) {
      .gallery {
        grid-template-columns: 1fr !important;
      }
    }

    /* 5. Gallery CTA Card matching image6.png */
    .gallery-cta {
      background: #111111 !important;
      border-radius: 16px !important;
      padding: 52px 32px !important;
      text-align: center !important;
      margin-top: 40px !important;
      border: 1px solid rgba(255, 255, 255, 0.08) !important;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15) !important;
    }
    .gallery-cta h3 {
      font-family: var(--font-display, inherit) !important;
      color: #ffffff !important;
      font-size: clamp(26px, 3.5vw, 36px) !important;
      font-weight: 700 !important;
      margin: 0 0 12px !important;
      letter-spacing: -0.02em !important;
    }
    .gallery-cta p {
      color: #a1a1aa !important;
      font-size: 16px !important;
      line-height: 1.6 !important;
      max-width: 580px !important;
      margin: 0 auto 28px !important;
    }
    .gallery-cta .button-white {
      background: #ffffff !important;
      color: #111111 !important;
      padding: 13px 32px !important;
      border-radius: 9999px !important;
      font-weight: 600 !important;
      font-size: 15px !important;
      text-decoration: none !important;
      display: inline-flex !important;
      align-items: center !important;
      gap: 6px !important;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15) !important;
      transition: background 0.2s ease, transform 0.2s ease !important;
    }
    .gallery-cta .button-white:hover {
      background: var(--brand-lime, #BFFF00) !important;
      color: #111111 !important;
      transform: translateY(-2px) !important;
    }

    /* 6. Footer Reorganization */
    .footer-location {
      font-size: 13px !important;
      color: var(--muted, #888888) !important;
      margin-top: 10px !important;
      line-height: 1.5 !important;
    }
    .footer-email-right {
      display: inline-block !important;
      margin-top: 14px !important;
      color: var(--muted, #888888) !important;
      text-decoration: none !important;
      font-size: 14px !important;
      transition: color 0.2s ease !important;
    }
    .footer-email-right:hover {
      color: var(--ink, #111111) !important;
    }
  </style>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="top">
  <a class="skip-link" href="#main"><?php esc_html_e('Skip to content', 'pixelsprings'); ?></a>

  <header class="site-header">
    <div class="header-inner">
      <a class="wordmark" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php esc_attr_e('Pixelsprings — home', 'pixelsprings'); ?>" data-testid="link-brand">
        <img class="wordmark-logo" src="<?php echo esc_url($theme_uri . '/assets/images/pixelsprings-logo.png'); ?>" alt="Pixelsprings" />
      </a>
      <nav class="nav-links" aria-label="<?php esc_attr_e('Main navigation', 'pixelsprings'); ?>">
        <a href="<?php echo esc_url(home_url('/services')); ?>" data-testid="link-nav-services"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/pricing')); ?>" data-testid="link-nav-pricing"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/work')); ?>" data-testid="link-nav-work"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/for-agencies')); ?>" data-testid="link-nav-for-agencies"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" data-testid="link-nav-contact"><?php esc_html_e('Contact', 'pixelsprings'); ?></a>
      </nav>
      <a class="nav-cta" href="<?php echo esc_url(home_url('/book-a-call')); ?>" data-testid="link-book-call-nav"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
      <button class="mobile-toggle" id="mobileMenuToggle" type="button" aria-label="<?php esc_attr_e('Open navigation menu', 'pixelsprings'); ?>" aria-expanded="false" aria-controls="mobile-navigation" data-testid="button-mobile-menu">☰</button>
    </div>
    <nav id="mobile-navigation" class="mobile-panel" aria-label="<?php esc_attr_e('Mobile navigation', 'pixelsprings'); ?>" style="display: none;" data-testid="mobile-navigation">
      <a href="<?php echo esc_url(home_url('/services')); ?>"><?php esc_html_e('Services', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/pricing')); ?>"><?php esc_html_e('Pricing', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/work')); ?>"><?php esc_html_e('Work', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/for-agencies')); ?>"><?php esc_html_e('For Agencies', 'pixelsprings'); ?></a>
      <a href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact', 'pixelsprings'); ?></a>
      <a class="button button-dark" href="<?php echo esc_url(home_url('/book-a-call')); ?>"><?php esc_html_e('Book a Call', 'pixelsprings'); ?></a>
    </nav>
  </header>
