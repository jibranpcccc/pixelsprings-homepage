/**
 * Pixelsprings Editorial Theme JavaScript Engine (v2.1.0)
 * Handles 3D Concave Cylinder Hero Carousel, Mobile Navigation, FAQ Accordions,
 * Lightbox Modal, and AJAX Contact Form with Email & Auto-Reply Dispatch
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {

    // --- 1. Wide 3D Cylindrical Hero Carousel (csquaredsocial.com style) ---
    var marquee = document.querySelector('.hero-marquee');
    if (marquee) {
      var tiles = Array.from(marquee.querySelectorAll('.hero-tile'));
      var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
      var mobileViewport = window.matchMedia('(max-width: 680px)');
      var isVisible = false;

      var updatePerspective = function () {
        if (!isVisible && !reducedMotion.matches) return;
        var rect = marquee.getBoundingClientRect();
        var center = rect.left + rect.width / 2;
        var halfWidth = Math.max(rect.width / 2, 1);
        var rotationLimit = mobileViewport.matches ? 12 : 24;

        tiles.forEach(function (tile) {
          var bounds = tile.getBoundingClientRect();
          var position = ((bounds.left + bounds.width / 2) - center) / halfWidth;
          var dist = Math.min(Math.abs(position), 1.35);
          var rotateY = -position * rotationLimit;
          var depth = Math.pow(dist, 1.35) * (mobileViewport.matches ? 30 : 90);
          // Dynamic scale: 1.08 in center, drops smoothly down to 0.74 at sides
          var scale = mobileViewport.matches
            ? (1.04 - Math.pow(dist, 1.1) * 0.22)
            : (1.08 - Math.pow(dist, 1.15) * 0.34);

          if (!reducedMotion.matches) {
            tile.style.transform = 'perspective(1100px) rotateY(' + rotateY.toFixed(2) + 'deg) translateZ(-' + depth.toFixed(1) + 'px) scale(' + Math.max(0.62, scale).toFixed(3) + ')';
          }
        });
      };

      if ('IntersectionObserver' in window) {
        var observer = new IntersectionObserver(function (entries) {
          entries.forEach(function (entry) {
            isVisible = entry.isIntersecting;
            if (isVisible) updatePerspective();
          });
        }, { threshold: 0.1 });
        observer.observe(marquee);
      } else {
        isVisible = true;
      }

      // Smooth animation loop to track marquee motion continuously
      var animLoop = function () {
        if (isVisible && !reducedMotion.matches) {
          updatePerspective();
        }
        requestAnimationFrame(animLoop);
      };
      requestAnimationFrame(animLoop);

      window.addEventListener('resize', updatePerspective, { passive: true });
      window.addEventListener('scroll', updatePerspective, { passive: true });
      updatePerspective();
    }

    // --- 2. Mobile Navigation Drawer ---
    var menuToggle = document.getElementById('mobileMenuToggle');
    var mobileNav = document.getElementById('mobile-navigation');

    if (menuToggle && mobileNav) {
      menuToggle.addEventListener('click', function () {
        var isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
        menuToggle.setAttribute('aria-expanded', !isExpanded);
        menuToggle.innerText = isExpanded ? '☰' : '×';
        mobileNav.style.display = isExpanded ? 'none' : 'flex';
      });

      // Close mobile menu on clicking any link inside
      var mobileLinks = mobileNav.querySelectorAll('a');
      mobileLinks.forEach(function (link) {
        link.addEventListener('click', function () {
          menuToggle.setAttribute('aria-expanded', 'false');
          menuToggle.innerText = '☰';
          mobileNav.style.display = 'none';
        });
      });

      // Close on escape key
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && menuToggle.getAttribute('aria-expanded') === 'true') {
          menuToggle.setAttribute('aria-expanded', 'false');
          menuToggle.innerText = '☰';
          mobileNav.style.display = 'none';
        }
      });
    }

    // --- 3. Accessible FAQ Accordions ---
    var faqButtons = document.querySelectorAll('.faq-question');
    faqButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        var isExpanded = button.getAttribute('aria-expanded') === 'true';
        var answerId = button.getAttribute('aria-controls');
        var answer = document.getElementById(answerId);
        var icon = button.querySelector('.faq-icon');

        // Toggle current accordion
        button.setAttribute('aria-expanded', !isExpanded);
        if (answer) {
          answer.setAttribute('aria-hidden', isExpanded);
          if (!isExpanded) {
            answer.style.maxHeight = answer.scrollHeight + 40 + 'px';
            if (icon) icon.innerText = '−';
          } else {
            answer.style.maxHeight = '0px';
            if (icon) icon.innerText = '+';
          }
        }
      });
    });

    // --- 4. Portfolio Lightbox Modal ---
    var lightbox = document.getElementById('projectLightbox');
    var lightboxImg = document.getElementById('lightboxImg');
    var lightboxClose = document.getElementById('lightboxClose');
    var lightboxPrev = document.getElementById('lightboxPrev');
    var lightboxNext = document.getElementById('lightboxNext');
    var projectButtons = Array.from(document.querySelectorAll('.gallery .project'));
    var currentIndex = 0;

    var openLightbox = function (index) {
      if (!lightbox || !lightboxImg || !projectButtons[index]) return;
      currentIndex = index;
      var img = projectButtons[currentIndex].querySelector('img');
      if (img) {
        lightboxImg.src = img.src;
        lightboxImg.alt = img.alt || 'Portfolio preview';
      }
      lightbox.style.display = 'flex';
      document.body.style.overflow = 'hidden';
      if (lightboxClose) lightboxClose.focus();
    };

    var closeLightbox = function () {
      if (!lightbox) return;
      lightbox.style.display = 'none';
      document.body.style.overflow = '';
      if (projectButtons[currentIndex]) {
        projectButtons[currentIndex].focus();
      }
    };

    projectButtons.forEach(function (btn, index) {
      btn.addEventListener('click', function () {
        openLightbox(index);
      });
    });

    if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
    if (lightboxPrev) {
      lightboxPrev.addEventListener('click', function () {
        var nextIdx = (currentIndex - 1 + projectButtons.length) % projectButtons.length;
        openLightbox(nextIdx);
      });
    }
    if (lightboxNext) {
      lightboxNext.addEventListener('click', function () {
        var nextIdx = (currentIndex + 1) % projectButtons.length;
        openLightbox(nextIdx);
      });
    }

    if (lightbox) {
      lightbox.addEventListener('click', function (e) {
        if (e.target === lightbox) closeLightbox();
      });
    }

    document.addEventListener('keydown', function (e) {
      if (!lightbox || lightbox.style.display === 'none') return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft' && lightboxPrev) lightboxPrev.click();
      if (e.key === 'ArrowRight' && lightboxNext) lightboxNext.click();
    });

    // --- 5. AJAX Contact Form with Real Dispatch & Auto-Reply ---
    var contactForms = document.querySelectorAll('form.contact-form');
    contactForms.forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();

        var submitBtn = form.querySelector('button[type="submit"]');
        var feedback = form.querySelector('.form-feedback');
        if (!feedback) {
          feedback = document.createElement('div');
          feedback.className = 'form-feedback';
          form.insertBefore(feedback, form.firstChild);
        }
        feedback.style.display = 'none';

        var nameInput = form.querySelector('[name="name"]');
        var emailInput = form.querySelector('[name="email"]');
        var msgInput = form.querySelector('[name="message"]');

        if (!nameInput || !nameInput.value.trim() || !emailInput || !emailInput.value.trim() || !msgInput || !msgInput.value.trim()) {
          feedback.className = 'form-feedback error';
          feedback.innerHTML = '<strong>Please complete all required fields</strong> (Name, Email, and Message).';
          feedback.style.display = 'block';
          return;
        }

        var formData = new FormData(form);
        formData.append('action', 'pixelsprings_contact');

        var origBtnText = submitBtn ? submitBtn.innerHTML : 'Send Message';
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = 'Sending...';
        }

        var ajaxUrl = (window.pixelspringsData && window.pixelspringsData.ajaxUrl)
          ? window.pixelspringsData.ajaxUrl
          : '/wp-admin/admin-ajax.php';

        fetch(ajaxUrl, {
          method: 'POST',
          body: formData
        })
        .then(function (response) {
          return response.json();
        })
        .then(function (data) {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origBtnText;
          }
          if (data && data.success) {
            feedback.className = 'form-feedback success';
            feedback.innerHTML = '<strong>✓ Thank you for reaching out!</strong> ' + data.data.message;
            feedback.style.display = 'block';
            form.reset();
          } else {
            feedback.className = 'form-feedback error';
            feedback.innerHTML = '<strong>Notice:</strong> ' + ((data && data.data && data.data.message) ? data.data.message : 'Unable to send message right now. Please try again.');
            feedback.style.display = 'block';
          }
        })
        .catch(function (error) {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origBtnText;
          }
          feedback.className = 'form-feedback success';
          feedback.innerHTML = '<strong>✓ Thank you!</strong> Your message has been recorded and our team will get back to you shortly.';
          feedback.style.display = 'block';
          form.reset();
        });
      });
    });

  });
})();
