<?php
/**
 * Pixelsprings Editorial Theme Functions and Definitions
 *
 * @package Pixelsprings
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('PIXELSPRINGS_VERSION', '3.1.0.' . time());

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function pixelsprings_setup() {
    load_theme_textdomain('pixelsprings', get_template_directory() . '/languages');

    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(1200, 800, true);

    register_nav_menus(array(
        'primary' => esc_html__('Primary Header Navigation', 'pixelsprings'),
        'footer'  => esc_html__('Footer Navigation', 'pixelsprings'),
    ));

    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
}
add_action('after_setup_theme', 'pixelsprings_setup');

/**
 * Enqueue scripts and styles.
 */
function pixelsprings_scripts() {
    // Web Fonts (Satoshi from Fontshare and Plus Jakarta Sans from Google Fonts)
    wp_enqueue_style('fontshare-satoshi', 'https://api.fontshare.com/v2/css?f[]=satoshi@400,500,600,700&display=swap', array(), null);
    wp_enqueue_style('google-jakarta', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap', array(), null);

    // Main Compiled & Normalized CSS
      $css_file = get_template_directory() . '/assets/css/main.css';
  $css_ver = file_exists($css_file) ? filemtime($css_file) : time();
  $js_file = get_template_directory() . '/assets/js/pixelsprings.js';
  $js_ver = file_exists($js_file) ? filemtime($js_file) : time();

  wp_enqueue_style('pixelsprings-main', get_template_directory_uri() . '/assets/css/main.css', array(), $css_ver);
  wp_enqueue_style('pixelsprings-style', get_stylesheet_uri(), array('pixelsprings-main'), $css_ver);
  wp_enqueue_script('pixelsprings-script', get_template_directory_uri() . '/assets/js/pixelsprings.js', array(), $js_ver, true);

    // Pass AJAX endpoint and config to frontend JS
    wp_localize_script('pixelsprings-script', 'pixelspringsData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('pixelsprings_contact_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'pixelsprings_scripts');

/**
 * Helper to retrieve Stripe checkout URLs for plans
 */
function pixelsprings_get_checkout_url($plan = 'spark') {
    $default_links = array(
        'spark' => 'https://buy.stripe.com/pixelsprings_spark',
        'flow'  => 'https://buy.stripe.com/pixelsprings_flow',
        'forge' => 'https://buy.stripe.com/pixelsprings_forge',
    );
    $option_key = 'pixelsprings_stripe_' . sanitize_key($plan);
    $custom_url = get_option($option_key);
    if (!empty($custom_url)) {
        return $custom_url;
    }
    return isset($default_links[$plan]) ? $default_links[$plan] : home_url('/pricing');
}

/**
 * Handle Contact Form AJAX Submission with email delivery and auto-reply
 */
function pixelsprings_ajax_contact_handler() {
    $name    = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $email   = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $company = isset($_POST['company']) ? sanitize_text_field(wp_unslash($_POST['company'])) : '';
    $service = isset($_POST['service']) ? sanitize_text_field(wp_unslash($_POST['service'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    $hp      = isset($_POST['_ps_hp']) ? sanitize_text_field(wp_unslash($_POST['_ps_hp'])) : '';

    // Spam honeypot detection
    if (!empty($hp)) {
        wp_send_json_success(array('message' => 'Thank you! Your message has been received.'));
    }

    if (empty($name) || empty($email) || empty($message) || !is_email($email)) {
        wp_send_json_error(array('message' => 'Please provide a valid name, email address, and message.'));
    }

    // 1. Persist submission locally in WordPress options so zero leads are ever lost
    $inquiries = get_option('pixelsprings_contact_inquiries', array());
    if (!is_array($inquiries)) {
        $inquiries = array();
    }
    $inquiries[] = array(
        'date'    => current_time('mysql'),
        'name'    => $name,
        'email'   => $email,
        'company' => $company,
        'service' => $service,
        'message' => $message,
        'ip'      => sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? '')),
    );
    // Keep up to 200 recent inquiries
    if (count($inquiries) > 200) {
        $inquiries = array_slice($inquiries, -200);
    }
    update_option('pixelsprings_contact_inquiries', $inquiries, false);

    // 2. Send email notification to contact@pixelsprings.com
    $to = 'contact@pixelsprings.com';
    $subject = 'New Inquiry from Pixelsprings: ' . $name;
    $body = "You have received a new contact submission from pixelsprings.com:

";
    $body .= "Name: " . $name . "
";
    $body .= "Email: " . $email . "
";
    $body .= "Company / Website: " . ($company ?: 'Not provided') . "
";
    $body .= "Area of Interest: " . ($service ?: 'General Inquiry') . "

";
    $body .= "Message:
" . $message . "

";
    $body .= "--
Sent from Pixelsprings Contact Form";

    $headers = array(
        'From: Pixelsprings Website <contact@pixelsprings.com>',
        'Reply-To: ' . $name . ' <' . $email . '>',
    );
    @wp_mail($to, $subject, $body, $headers);

    // 3. Send automatic confirmation reply to visitor
    $reply_subject = 'We received your message — Pixelsprings';
    $reply_body = "Hi " . $name . ",

";
    $reply_body .= "Thank you for reaching out to Pixelsprings.

";
    $reply_body .= "We've received your inquiry and our team is currently reviewing your project requirements. We typically respond within 1 business day.

";
    $reply_body .= "If your project is time-sensitive or you prefer a quick introductory conversation, you can also schedule a call with us anytime:
";
    $reply_body .= home_url('/book-a-call') . "

";
    $reply_body .= "Best regards,
";
    $reply_body .= "Umair & Noman
";
    $reply_body .= "Pixelsprings Team
";
    $reply_body .= "https://pixelsprings.com
";

    $reply_headers = array(
        'From: Pixelsprings <contact@pixelsprings.com>',
    );
    @wp_mail($email, $reply_subject, $reply_body, $reply_headers);

    wp_send_json_success(array(
        'message' => "Thank you for reaching out! We've received your message and sent a confirmation to your email. We'll be in touch shortly."
    ));
}
add_action('wp_ajax_pixelsprings_contact', 'pixelsprings_ajax_contact_handler');
add_action('wp_ajax_nopriv_pixelsprings_contact', 'pixelsprings_ajax_contact_handler');

/**
 * Customize Document Title to match Replit & Editorial specifications
 */
function pixelsprings_document_title_parts($title) {
    if (is_front_page()) {
        $title['title'] = 'Pixelsprings — Design + Development, on Subscription';
        unset($title['site']);
        unset($title['tagline']);
    } elseif (is_page('services')) {
        $title['title'] = 'Services — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('pricing')) {
        $title['title'] = 'Pricing — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('work')) {
        $title['title'] = 'Work — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('for-agencies')) {
        $title['title'] = 'For Agencies — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('book-a-call')) {
        $title['title'] = 'Book a Call — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('contact')) {
        $title['title'] = 'Contact — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('privacy')) {
        $title['title'] = 'Privacy Policy — Pixelsprings';
        unset($title['site']);
    } elseif (is_page('terms')) {
        $title['title'] = 'Terms of Service — Pixelsprings';
        unset($title['site']);
    }
    return $title;
}
add_filter('document_title_parts', 'pixelsprings_document_title_parts');

/**
 * Standard Privacy Policy Content
 */
function pixelsprings_get_default_privacy_content() {
    return '<h2>1. Introduction</h2>
<p>Pixelsprings ("we", "our", or "us") provides monthly design, web, and development subscription services to agency partners and growing businesses worldwide. We are committed to safeguarding the privacy and confidentiality of our clients, visitors, and prospective partners.</p>

<h2>2. Information We Collect</h2>
<p>We collect information you voluntarily provide to us when submitting inquiries, booking consultations, or subscribing to our production plans. This includes:</p>
<ul>
  <li><strong>Contact Details:</strong> Your name, business email address, company name, website URL, and phone number.</li>
  <li><strong>Project Briefs & Creative Assets:</strong> Brand guidelines, design files, technical specifications, and communication regarding requested work.</li>
  <li><strong>Payment Information:</strong> All financial transactions and subscription billings are processed securely through Stripe. We do not store or process raw credit card numbers on our servers.</li>
</ul>

<h2>3. How We Use Your Information</h2>
<p>We use your information exclusively to:</p>
<ul>
  <li>Deliver, produce, and manage your subscription requests.</li>
  <li>Maintain active project queues, communicate reviews, and share deliverables.</li>
  <li>Process monthly subscription billings through our payment processor (Stripe).</li>
  <li>Respond to contact inquiries and schedule introductory consultation calls.</li>
</ul>

<h2>4. Confidentiality, White-Label & Non-Disclosure</h2>
<p>We treat all client assets, designs, code, and project briefs as strictly confidential. As a dedicated behind-the-scenes production partner for agencies, we adhere to rigorous white-label standards. We do not contact your clients directly or brand deliverables with Pixelsprings marks without your explicit authorization. We are fully NDA-friendly.</p>

<h2>5. Data Security & Storage</h2>
<p>We implement industry-standard technical and operational safeguards to protect your personal and project information against unauthorized access, loss, or alteration. Approved deliverables and files are shared through secure, encrypted cloud repositories.</p>

<h2>6. Your Rights & Contact</h2>
<p>You may request access to, correction of, or deletion of your personal data at any time. For questions regarding this Privacy Policy, please contact us at <a href="mailto:contact@pixelsprings.com">contact@pixelsprings.com</a>.</p>';
}

/**
 * Standard Terms of Service Content
 */
function pixelsprings_get_default_terms_content() {
    return '<h2>1. Agreement to Terms</h2>
<p>By subscribing to or using Pixelsprings services, you agree to be bound by these Terms of Service. Pixelsprings provides subscription-based creative design, UI/UX, website design, and development services based in Texas, USA.</p>

<h2>2. Subscription Plans & Production Capacity</h2>
<p>Pixelsprings operates on a flexible monthly subscription model without long-term contracts. The active request capacity is determined by your chosen plan:</p>
<ul>
  <li><strong>Pixel Spark ($799/month):</strong> 1 active request at a time. Ideal for graphic design, branding, and marketing collateral.</li>
  <li><strong>Pixel Flow ($1,499/month):</strong> 2 active requests at a time. Covers design, UI/UX, and website design.</li>
  <li><strong>Pixel Forge ($2,499/month):</strong> 3 active requests at a time. Full-suite design, web, and custom development.</li>
</ul>
<p>Unlimited requests may be added to your queue. Work is completed sequentially within your plan\'s dedicated active capacity. First drafts typically arrive within 2-3 business days. Larger websites and complex development are divided into clear milestones.</p>

<h2>3. Intellectual Property & Ownership</h2>
<p>Upon receipt of full payment for the applicable subscription billing cycle, you own 100% of all approved deliverables, final artwork, custom code, and design files created for your account. Pixelsprings retains no ownership rights over your finished deliverables.</p>

<h2>4. Revisions & Reviews</h2>
<p>You can request unlimited revisions within the original scope while a request is active. If feedback materially alters the deliverable or introduces an entirely new brief, it will be organized as a subsequent request in your queue.</p>

<h2>5. White-Label & Agency Partnership</h2>
<p>When working with agency partners, Pixelsprings operates strictly behind the scenes under your brand. We will never communicate directly with your clients unless explicitly authorized in writing by your team.</p>

<h2>6. Scope Exclusions</h2>
<p>Motion graphics, video editing, 3D design, and React or Java development are excluded from our subscription scope. Development in Pixel Forge focuses on custom coding, advanced WordPress, WooCommerce, e-commerce, and API integrations.</p>

<h2>7. Cancellation & Pauses</h2>
<p>You may cancel your subscription at any time prior to your next monthly billing renewal. Upon cancellation, your production queue remains active until the conclusion of your paid period.</p>

<h2>8. Governing Law & Contact</h2>
<p>These terms are governed by the laws of the State of Texas, USA. For inquiries regarding our terms, reach out to <a href="mailto:contact@pixelsprings.com">contact@pixelsprings.com</a>.</p>';
}

/**
 * Automatically initialize pages, navigation, and reading settings on theme activation.
 */
function pixelsprings_auto_initialize_theme() {
    $pages_to_create = array(
        'home' => array(
            'title'    => 'Home',
            'slug'     => 'home',
            'template' => 'front-page.php',
            'content'  => '',
        ),
        'services' => array(
            'title'    => 'Services',
            'slug'     => 'services',
            'template' => 'page-services.php',
            'content'  => '',
        ),
        'pricing' => array(
            'title'    => 'Pricing',
            'slug'     => 'pricing',
            'template' => 'page-pricing.php',
            'content'  => '',
        ),
        'work' => array(
            'title'    => 'Work',
            'slug'     => 'work',
            'template' => 'page-work.php',
            'content'  => '',
        ),
        'for-agencies' => array(
            'title'    => 'For Agencies',
            'slug'     => 'for-agencies',
            'template' => 'page-for-agencies.php',
            'content'  => '',
        ),
        'book-a-call' => array(
            'title'    => 'Book a Call',
            'slug'     => 'book-a-call',
            'template' => 'page-book-a-call.php',
            'content'  => '',
        ),
        'contact' => array(
            'title'    => 'Contact',
            'slug'     => 'contact',
            'template' => 'page-contact.php',
            'content'  => '',
        ),
        'privacy' => array(
            'title'    => 'Privacy Policy',
            'slug'     => 'privacy',
            'template' => 'page-legal.php',
            'content'  => pixelsprings_get_default_privacy_content(),
        ),
        'terms' => array(
            'title'    => 'Terms of Service',
            'slug'     => 'terms',
            'template' => 'page-legal.php',
            'content'  => pixelsprings_get_default_terms_content(),
        ),
    );

    $created_page_ids = array();

    foreach ($pages_to_create as $key => $page_info) {
        $existing = get_page_by_path($page_info['slug']);
        if (!$existing) {
            $page_id = wp_insert_post(array(
                'post_title'     => $page_info['title'],
                'post_name'      => $page_info['slug'],
                'post_status'    => 'publish',
                'post_type'      => 'page',
                'post_content'   => $page_info['content'],
                'comment_status' => 'closed',
            ));
            if ($page_id && !is_wp_error($page_id)) {
                if (!empty($page_info['template'])) {
                    update_post_meta($page_id, '_wp_page_template', $page_info['template']);
                }
                $created_page_ids[$key] = $page_id;
            }
        } else {
            $created_page_ids[$key] = $existing->ID;
            if (!empty($page_info['template'])) {
                update_post_meta($existing->ID, '_wp_page_template', $page_info['template']);
            }
            // Update content for privacy & terms if currently blank
            if (in_array($key, array('privacy', 'terms')) && empty(trim($existing->post_content))) {
                wp_update_post(array(
                    'ID'           => $existing->ID,
                    'post_content' => $page_info['content'],
                    'post_status'  => 'publish',
                ));
            }
            if ($existing->post_status !== 'publish') {
                wp_update_post(array('ID' => $existing->ID, 'post_status' => 'publish'));
            }
        }
    }

    // Set static front page
    if (!empty($created_page_ids['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $created_page_ids['home']);
    }

    // Ensure pretty permalinks
    if (get_option('permalink_structure') === '') {
        update_option('permalink_structure', '/%postname%/');
    }
    flush_rewrite_rules();

    // Create Primary Menu if not already set
    $menu_name = 'Pixelsprings Primary Menu';
    $menu_exists = wp_get_nav_menu_object($menu_name);

    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);

        $nav_items = array(
            array('title' => 'Services', 'url' => home_url('/services')),
            array('title' => 'Pricing', 'url' => home_url('/pricing')),
            array('title' => 'Work', 'url' => home_url('/work')),
            array('title' => 'For Agencies', 'url' => home_url('/for-agencies')),
            array('title' => 'Contact', 'url' => home_url('/contact')),
            array('title' => 'Book a Call', 'url' => home_url('/book-a-call')),
        );

        foreach ($nav_items as $item) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title'   => $item['title'],
                'menu-item-url'     => $item['url'],
                'menu-item-status'  => 'publish',
            ));
        }

        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_id;
        $locations['footer']  = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}
add_action('after_switch_theme', 'pixelsprings_auto_initialize_theme');

/**
 * Pixelsprings Fast Static Page Cache (Drastically optimizes TTFB and page loading speed)
 */
function pixelsprings_start_page_cache() {
    if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX) || (defined('DOING_CRON') && DOING_CRON)) {
        return;
    }
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] !== 'GET') {
        return;
    }
    if (is_user_logged_in() || !empty($_COOKIE['wordpress_logged_in_'])) {
        return;
    }

    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    if (strpos($uri, 'wp-') !== false || strpos($uri, 'preview=true') !== false) {
        return;
    }

    $upload_dir = wp_upload_dir();
    $cache_dir = $upload_dir['basedir'] . '/pixelsprings-cache';
    if (!file_exists($cache_dir)) {
        @mkdir($cache_dir, 0755, true);
    }

    $cache_key = md5($uri);
    $cache_file = $cache_dir . '/' . $cache_key . '.html';

    if (file_exists($cache_file) && (time() - filemtime($cache_file) < 3600)) {
        header('X-Pixelsprings-Cache: HIT');
        header('Cache-Control: public, max-age=3600');
        header('Content-Type: text/html; charset=UTF-8');
        readfile($cache_file);
        exit;
    }

    ob_start(function($buffer) use ($cache_file) {
        if (!empty($buffer) && strlen($buffer) > 1000 && http_response_code() === 200 && strpos($buffer, '</html>') !== false) {
            $buffer_with_comment = $buffer . "\n<!-- Pixelsprings Fast Cache: Generated " . gmdate('Y-m-d H:i:s') . " UTC -->";
            @file_put_contents($cache_file, $buffer_with_comment);
            return $buffer_with_comment;
        }
        return $buffer;
    });
}
add_action('template_redirect', 'pixelsprings_start_page_cache', 1);

function pixelsprings_clear_page_cache() {
    $upload_dir = wp_upload_dir();
    $cache_dir = $upload_dir['basedir'] . '/pixelsprings-cache';
    if (is_dir($cache_dir)) {
        $files = @glob($cache_dir . '/*.html');
        if ($files) {
            foreach ($files as $f) {
                @unlink($f);
            }
        }
    }
}
add_action('save_post', 'pixelsprings_clear_page_cache');
add_action('after_switch_theme', 'pixelsprings_clear_page_cache');

// Remove WordPress core emoji bloat to improve page speed
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('admin_print_styles', 'print_emoji_styles');
remove_filter('the_content_feed', 'wp_staticize_emoji');
remove_filter('comment_text_rss', 'wp_staticize_emoji');
remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
add_filter('tiny_mce_plugins', function($plugins) {
    return is_array($plugins) ? array_diff($plugins, array('wpemoji')) : array();
});

// Defer non-critical JavaScript to prevent render-blocking
add_filter('script_loader_tag', function($tag, $handle) {
    if ('pixelsprings-script' === $handle && strpos($tag, 'defer') === false) {
        return str_replace(' src', ' defer src', $tag);
    }
    return $tag;
}, 10, 2);
