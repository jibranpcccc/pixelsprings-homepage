<?php
/**
 * Template Name: Legal Page (Privacy & Terms)
 * Description: Editorial layout for legal pages like Privacy Policy and Terms of Service.
 *
 * @package Pixelsprings
 */
get_header();
$theme_uri = get_template_directory_uri();
?>

<main id="main" class="inner-main">
  <!-- PAGE HERO -->
  <section class="inner-hero inner-hero-left">
    <div class="wrap">
      <div class="eyebrow"><?php esc_html_e('Legal & Policies', 'pixelsprings'); ?></div>
      <h1><?php the_title(); ?></h1>
      <p class="hero-copy"><?php esc_html_e('Pixelsprings — Design & Development Subscription. Clear, transparent, and fair policies.', 'pixelsprings'); ?></p>
    </div>
  </section>

  <!-- LEGAL CONTENT -->
  <section class="section legal-section">
    <div class="wrap">
      <div class="legal-container">
        <?php
        if (have_posts()) :
          while (have_posts()) : the_post();
            the_content();
          endwhile;
        endif;
        ?>
      </div>
    </div>
  </section>
</main>

<?php get_footer(); ?>
